# FRIDAY - Personal AI Assistant

FRIDAY is a native Kotlin and Jetpack Compose Android assistant (`com.aditya.friday`) with a dark cyan sci-fi interface, Android speech recognition and TextToSpeech, local Hindi/Hinglish/English command handling, optional OpenAI-compatible online AI, and user-enabled accessibility actions.

## Build

Requirements: JDK 17, Android SDK Platform 35, Android Build Tools 35.0.0, and an internet connection for the first Gradle dependency download.

```sh
./gradlew clean testDebugUnitTest assembleDebug
```

The installable debug package is generated at:

```text
app/build/outputs/apk/debug/app-debug.apk
```

Install on a compatible Android phone with Android Studio's Run action or:

```sh
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

For a direct phone install, download `app/build/outputs/apk/debug/app-debug.apk`, open it in the Android file manager, and approve the one-time **Install unknown apps** prompt for that file manager if Android displays it. Review the permission prompts; microphone is requested only when using a voice control.

The APK is a debug-signed build for installation and evaluation. A production release needs a signing key managed by the publisher; no signing secret is included.

## First Run

1. Install and open FRIDAY. The app asks for microphone permission only when a voice control is used. Manual text input works without it.
2. Tap **Start Listening** for the configured Android recognition session, or press and hold **Push To Talk** and release to finish the utterance. **Stop** cancels recognition and speech output.
3. Android supplies recognition and TTS engines. Language packs, offline recognition, installed voices, and recognition quality depend on the device and its speech services.
4. For Back, Home, scroll, accessible text entry, and WhatsApp assistance, open **Settings -> Accessibility Automation -> Open Accessibility Settings** and manually enable FRIDAY. Disable it there at any time.
5. Phone Lock is optional. FRIDAY requests only Android's force-lock policy; the system activation screen is controlled by the user. Use Android Security settings to deactivate the admin.

## Online AI Setup

1. Create a provider API key in the provider's own account dashboard. Groq free-tier access is subject to the provider's current model availability and rate limits; FRIDAY does not provide unlimited or paid API access.
2. In **Settings -> AI Provider**, enable **Online AI**, select Groq or a custom OpenAI-compatible provider, and check the endpoint. The Groq default is `https://api.groq.com/openai/v1/chat/completions`.
3. Enter a model name currently available to your account. The model field is deliberately editable and has no bundled model-availability assumption.
4. Paste the key and tap **Save Key**. It is encrypted with an AES/GCM key held by Android Keystore. The key is not displayed again, written to logs, or bundled in the app.
5. Tap **Test Connection**. FRIDAY makes a real, non-streaming chat-completions request and displays the provider's actual response or an HTTP/network failure. Cloud conversations require internet and are sent to the configured provider.

Remote endpoints must use HTTPS. Plain HTTP is accepted by the URL validator only for local development hosts; Android's network security policy still blocks cleartext app traffic. Provider model changes and free-tier limits are controlled by the provider.

## Accessibility And WhatsApp

Accessibility is opt-in, user-controlled Android UI automation. The service does not start listening to the microphone, collect screen contents for upload, bypass app security, or use unofficial WhatsApp APIs.

- Open WhatsApp and search for a contact using visible accessible labels; the service accepts only a unique exact contact text match and waits for an accessible conversation composer.
- A message is prepared only after FRIDAY has a recipient in temporary conversation context. FRIDAY reads back the recipient and message and requires a separate **Haan / Yes** confirmation.
- After confirmation, FRIDAY tries to set the message in the verified WhatsApp conversation, tap an accessible Send control, and check that the message appears in the conversation with the composer cleared. This verifies only a visible local UI result, not WhatsApp delivery or read status.
- If the target chat, field, or Send control cannot be verified, the action fails or opens a manual WhatsApp text handoff. A handoff never sends a message automatically. Select the recipient and tap Send yourself.
- WhatsApp UI labels and layout change across versions, languages, and OEM accessibility layers. Review the chat and message before confirming; the system-level permission and any manual steps remain yours.

## Wake Word And Background Privacy

The configurable wake-word preference is stored, but no always-on wake-word model is bundled. The status truthfully remains **NOT RUNNING**. FRIDAY does not keep the microphone open in the background or use a fake wake-word detector. Use the explicit Start Listening session or Push To Talk instead. The Android microphone privacy indicator is shown while the platform recognizer is active.

## Local Commands

Local command handling includes common English/Hinglish variants for opening named apps, phone/Wi-Fi/Bluetooth/display settings, Google web search, media-volume adjustment, Back/Home/scroll via the enabled accessibility service, supported focused text input, and an optional device-admin screen lock. Installed apps and OEM settings intents vary. An action is reported successful only when Android accepts the intent/API call; UI automation reports a separate verified or failed result.

Conversation recipient, pending confirmation, current app, and recent AI context live temporarily in memory. Command history and profile/settings are stored locally. API keys are stored separately as encrypted ciphertext. Enabling cloud AI sends relevant recent conversation turns to the configured provider.

## Tests And Verification

- `CommandParserTest`: common Hinglish commands, speech correction, recipient context, and confirmation safety.
- `ActionValidatorTest`: allow-listed structured action parsing and rejection of unknown action types.
- `GroqAiClientTest`: an OpenAI-compatible request against a local MockWebServer plus HTTPS endpoint validation.
- Android compilation and on-device permission flows require Android SDK/device services. A successful local Gradle build does not claim WhatsApp UI, microphone, OEM settings, or physical-device behavior was exercised.

Environment verification: `clean testDebugUnitTest assembleDebug` completed successfully with JDK 17 and Android SDK 35; all 14 JVM tests passed. The APK signature and Android package metadata were verified with Android Build Tools 35.0.0. The separate Vite browser companion also passes `npm run build`. No emulator or physical Android device was available for interactive validation.

Run the JVM unit suite and APK build together with the command above. GitHub Actions runs the same tasks and publishes `friday-debug-apk` as a downloadable artifact.

## Known Limitations

- Always-on wake-word detection is not implemented; the app explicitly reports this.
- Android speech recognition, downloaded offline language data, Hindi TTS voices, and speech quality vary by device, Android version, and installed engine.
- Accessibility features require the user to enable the service and depend on the current foreground app's accessible UI. No permission bypass or WhatsApp delivery API is used.
- Direct APK installation is debug-signed. Accessibility and Device Admin prompts must be accepted manually.
- Groq free-tier models, quotas, rate limits, and account eligibility change over time. Supply a currently supported model name yourself.
- The source includes a browser companion under `src/` for UI preview and browser-only speech/cloud interactions. It is not a replacement for the Android APK and cannot control Android apps or run Android Accessibility automation.

## Credits And Licenses

**FRIDAY - Personal AI Assistant**  
Whole credit goes to Aditya.  
© 2026 Aditya. All rights reserved.

Third-party dependency attribution and license references are in [`THIRD_PARTY_NOTICES.md`](THIRD_PARTY_NOTICES.md) and `app/src/main/assets/THIRD_PARTY_NOTICES.txt`.