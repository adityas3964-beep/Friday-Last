import { type CSSProperties, type FormEvent, type PointerEvent, useCallback, useEffect, useMemo, useRef, useState } from "react";

type Page = "HOME" | "LOG" | "PROFILE" | "SETTINGS";
type Mode = "READY" | "LISTENING" | "THINKING" | "SPEAKING" | "ERROR";
type Transcript = { id: string; time: number; heard: string; response: string; engine: string; result: string };
type FridaySettings = {
  online: boolean;
  provider: "Groq" | "Custom OpenAI-compatible";
  endpoint: string;
  model: string;
  automaticRecognition: boolean;
  wakeWord: string;
  preferredName: string;
  assistantName: string;
  language: "hi-IN" | "en-IN";
  voice: "AUTO" | "hi-IN" | "en-IN";
};

type WebRecognitionResult = { transcript: string };
type WebRecognitionEvent = { results: ArrayLike<ArrayLike<WebRecognitionResult>> };
type WebRecognition = {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  onresult: ((event: WebRecognitionEvent) => void) | null;
  onerror: ((event: { error?: string }) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
  abort: () => void;
};
type FridayWindow = Window & {
  SpeechRecognition?: new () => WebRecognition;
  webkitSpeechRecognition?: new () => WebRecognition;
};

const DEFAULT_SETTINGS: FridaySettings = {
  online: false,
  provider: "Groq",
  endpoint: "https://api.groq.com/openai/v1/chat/completions",
  model: "",
  automaticRecognition: true,
  wakeWord: "FRIDAY",
  preferredName: "",
  assistantName: "FRIDAY",
  language: "hi-IN",
  voice: "AUTO",
};
const STORAGE_SETTINGS = "friday-companion-settings-v1";
const STORAGE_LOGS = "friday-companion-log-v1";
const waveHeights = [32, 48, 66, 84, 56, 39, 72, 95, 60, 43, 81, 64, 36, 76, 96, 58, 42, 85, 59, 34, 68, 92, 52, 40, 78, 98, 61, 35, 73, 88, 48, 33, 62, 94, 58, 39, 84, 69, 45, 94, 57, 76];

function readLocal<T>(key: string, fallback: T): T {
  try {
    const value = localStorage.getItem(key);
    return value ? { ...fallback, ...JSON.parse(value) } : fallback;
  } catch {
    return fallback;
  }
}

function timeLabel(timestamp: number) {
  return new Intl.DateTimeFormat(undefined, { hour: "2-digit", minute: "2-digit" }).format(timestamp);
}

function toneFor(result: string) {
  if (result.includes("SUCCESS") || result.includes("CONNECTED")) return "good";
  if (result.includes("FAILED")) return "bad";
  if (result.includes("CONFIRM") || result.includes("MANUAL") || result.includes("PERMISSION")) return "warn";
  return "muted";
}

export default function App() {
  const [page, setPage] = useState<Page>("HOME");
  const [settings, setSettings] = useState<FridaySettings>(() => readLocal(STORAGE_SETTINGS, DEFAULT_SETTINGS));
  const [logs, setLogs] = useState<Transcript[]>(() => {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_LOGS) ?? "[]") as Transcript[];
    } catch {
      return [];
    }
  });
  const [apiKey, setApiKey] = useState("");
  const [mode, setMode] = useState<Mode>("READY");
  const [recognized, setRecognized] = useState("");
  const [response, setResponse] = useState("Start listening, press to talk, or type a message.");
  const [lastEngine, setLastEngine] = useState("NOT USED");
  const [lastResult, setLastResult] = useState("READY");
  const [microphoneStatus, setMicrophoneStatus] = useState("NOT REQUESTED");
  const [onlineStatus, setOnlineStatus] = useState("NOT TESTED");
  const [onlineMessage, setOnlineMessage] = useState("A test sends a real request to your configured provider.");
  const [busy, setBusy] = useState(false);
  const [draft, setDraft] = useState("");
  const [connectionCheck, setConnectionCheck] = useState(false);
  const recognitionRef = useRef<WebRecognition | null>(null);
  const speechAvailable = useMemo(() => {
    const candidate = window as FridayWindow;
    return Boolean(candidate.SpeechRecognition || candidate.webkitSpeechRecognition);
  }, []);

  useEffect(() => {
    localStorage.setItem(STORAGE_SETTINGS, JSON.stringify(settings));
  }, [settings]);
  useEffect(() => {
    localStorage.setItem(STORAGE_LOGS, JSON.stringify(logs.slice(0, 30)));
  }, [logs]);

  const record = useCallback((heard: string, answer: string, engine: string, result: string) => {
    const item = { id: `${Date.now()}-${Math.random()}`, time: Date.now(), heard, response: answer, engine, result };
    setLogs((current) => [item, ...current].slice(0, 30));
    setLastEngine(engine);
    setLastResult(result);
  }, []);

  const speak = useCallback((text: string) => {
    if (!("speechSynthesis" in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = settings.voice === "AUTO" ? settings.language : settings.voice;
    utterance.rate = 0.96;
    utterance.onstart = () => setMode("SPEAKING");
    utterance.onend = () => setMode("READY");
    utterance.onerror = () => setMode("READY");
    window.speechSynthesis.speak(utterance);
  }, [settings.language, settings.voice]);

  const callProvider = useCallback(async (prompt: string, test = false) => {
    if (!settings.model.trim()) throw new Error("Enter a model currently supported by your provider.");
    if (!apiKey.trim()) throw new Error("Enter an API key in Settings. The browser companion keeps it in memory only.");
    if (!/^https:\/\//i.test(settings.endpoint.trim())) throw new Error("Use an HTTPS provider endpoint in the browser companion.");
    const response = await fetch(settings.endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey.trim()}` },
      body: JSON.stringify({
        model: settings.model.trim(),
        stream: false,
        messages: [
          {
            role: "system",
            content: `You are ${settings.assistantName}, a concise Hindi/Hinglish/English assistant. Address the user as ${settings.preferredName || "Boss"}. Return one JSON object with type CHAT and a response string. Never claim Android actions were performed in this browser.`,
          },
          { role: "user", content: test ? "Reply with one short word confirming this connection." : prompt },
        ],
      }),
    });
    if (!response.ok) {
      const explanation = response.status === 429
        ? "Provider rate limit reached. Free-tier quotas may apply; try again later."
        : response.status === 401 || response.status === 403
          ? "Provider rejected the key. Verify the key and account access."
          : `Provider returned HTTP ${response.status}. Check the endpoint, model, network, and account limits.`;
      throw new Error(explanation);
    }
    const data = await response.json() as { choices?: Array<{ message?: { content?: string } }> };
    const text = data.choices?.[0]?.message?.content?.trim();
    if (!text) throw new Error("The provider returned an empty response.");
    return text;
  }, [apiKey, settings]);

  const testConnection = async () => {
    setConnectionCheck(true);
    setOnlineStatus("TESTING");
    setOnlineMessage("Sending a live chat-completions request...");
    try {
      const result = await callProvider("Connection test", true);
      setOnlineStatus("CONNECTED");
      setOnlineMessage(`Provider responded: ${result.slice(0, 180)}`);
    } catch (error) {
      setOnlineStatus("FAILED");
      setOnlineMessage(error instanceof Error ? error.message : "The connection request failed.");
    } finally {
      setConnectionCheck(false);
    }
  };

  const processText = useCallback(async (value: string) => {
    const text = value.trim();
    if (!text || busy) return;
    setRecognized(text);
    setMode("THINKING");
    setBusy(true);
    let answer = "";
    let engine = "OFFLINE MODE";
    let result = "LOCAL FALLBACK";
    const lower = text.toLowerCase().replace(/[.,!?]/g, "");
    const appRequest = /\b(open|launch|kholo|khol|chalao|start)\b/.test(lower) || lower.includes("ki chat kholo");

    if (lower.includes("capital of india") || lower.includes("india ki capital") || lower.includes("india ka capital") || lower.includes("bharat ki rajdhani")) {
      answer = `${settings.preferredName ? `${settings.preferredName}, ` : ""}India ki rajdhani New Delhi hai.`;
      result = "LOCAL ANSWER";
    } else if (lower.includes("joke") || lower.includes("mazak") || lower.includes("majak")) {
      answer = "Computer ne chai kyun nahi pi? Uske paas cookies pehle se thi.";
      result = "LOCAL ANSWER";
    } else if (lower.includes("whatsapp") && lower.includes("message") && /bhej|send/.test(lower)) {
      answer = "Messages can only be sent by the native Android app after showing the recipient and getting your separate confirmation. No message was sent here.";
      result = "ANDROID APP REQUIRED";
    } else if (appRequest || /\b(back|scroll|volume|wifi|bluetooth|settings|home screen)\b/.test(lower)) {
      answer = "This browser companion cannot launch apps or control Android. No device action was performed; use the FRIDAY Android APK for this command.";
      result = "ANDROID APP REQUIRED";
    } else if (settings.online && apiKey.trim() && settings.model.trim()) {
      try {
        const content = await callProvider(text);
        let message = content;
        try {
          const candidate = JSON.parse(content) as { type?: string; response?: string };
          if (candidate.type && candidate.type !== "CHAT") {
            message = `The model suggested ${candidate.type}, but browser-to-Android automation is unavailable. No device action was run.`;
            result = "ACTION NOT EXECUTED";
          } else if (candidate.response) message = candidate.response;
        } catch {
          // Plain OpenAI-compatible text is displayed as returned.
        }
        answer = message;
        engine = "ONLINE AI";
        if (result !== "ACTION NOT EXECUTED") result = "AI RESPONSE";
      } catch (error) {
        answer = error instanceof Error ? `${error.message} Local commands remain available.` : "AI request failed. Local commands remain available.";
        result = "AI REQUEST FAILED";
      }
    } else {
      answer = settings.online
        ? "Online AI is enabled, but the browser companion needs a model and an in-memory API key. Local commands remain available."
        : "Online AI is off. Local answers and this browser companion's voice controls remain available.";
      result = "LOCAL COMMANDS READY";
    }

    setResponse(answer);
    record(text, answer, engine, result);
    setBusy(false);
    speak(answer);
  }, [apiKey, busy, callProvider, record, settings, speak]);

  const startListening = (pushToTalk = false) => {
    const host = window as FridayWindow;
    const Recognition = host.SpeechRecognition ?? host.webkitSpeechRecognition;
    if (!Recognition) {
      setMicrophoneStatus("UNAVAILABLE IN THIS BROWSER");
      setMode("ERROR");
      setResponse("This browser does not expose speech recognition. Type a command below or use the native Android app.");
      return;
    }
    try {
      recognitionRef.current?.abort();
      const recognition = new Recognition();
      recognition.lang = settings.language;
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.onresult = (event) => {
        const utterance = event.results[event.results.length - 1]?.[0]?.transcript?.trim();
        if (utterance) void processText(utterance);
      };
      recognition.onerror = (event) => {
        setMicrophoneStatus(event.error === "not-allowed" ? "PERMISSION DENIED" : `ERROR: ${event.error ?? "UNKNOWN"}`);
        setMode("ERROR");
      };
      recognition.onend = () => {
        setMicrophoneStatus((current) => current === "LISTENING" ? "READY" : current);
        setMode((current) => current === "LISTENING" ? "READY" : current);
      };
      recognitionRef.current = recognition;
      recognition.start();
      setMicrophoneStatus(pushToTalk ? "PUSH TO TALK" : "LISTENING");
      setMode("LISTENING");
    } catch {
      setMicrophoneStatus("RECOGNITION COULD NOT START");
      setMode("ERROR");
    }
  };

  const stopAll = () => {
    recognitionRef.current?.abort();
    recognitionRef.current = null;
    if ("speechSynthesis" in window) window.speechSynthesis.cancel();
    setMicrophoneStatus("STOPPED");
    setMode("READY");
  };

  const changeSettings = (patch: Partial<FridaySettings>) => setSettings((current) => ({ ...current, ...patch }));
  const submitInput = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const value = draft;
    setDraft("");
    void processText(value);
  };

  return (
    <div className="friday-shell">
      <div className="ambient-grid" aria-hidden="true" />
      <header className="topbar">
        <button className="brand-mark" onClick={() => setPage("HOME")} aria-label="FRIDAY home">
          <span className="brand-icon"><span /></span>
          <span className="brand-word">FRIDAY</span>
          <span className="brand-divider" />
          <span className="brand-caption">PERSONAL AI ASSISTANT</span>
        </button>
        <div className="topbar-right">
          <span className={`network-light ${onlineStatus === "CONNECTED" ? "on" : ""}`} />
          <span>{settings.online ? "ONLINE AI" : "LOCAL MODE"}</span>
          <button className="top-settings" onClick={() => setPage("SETTINGS")} aria-label="Settings"><SettingsIcon /></button>
        </div>
      </header>

      <main className="app-frame">
        <nav className="side-nav" aria-label="Main navigation">
          <div className="nav-cap">SYSTEM</div>
          {(["HOME", "LOG", "PROFILE", "SETTINGS"] as Page[]).map((item) => (
            <button key={item} className={`nav-item ${page === item ? "active" : ""}`} onClick={() => setPage(item)}>
              <span className="nav-tick" />{item}
            </button>
          ))}
          <div className="nav-footer"><span className="nav-footer-dot" /><span>ANDROID APP<br /><small>AVAILABLE IN PROJECT</small></span></div>
        </nav>

        <section className="main-content">
          {page === "HOME" && (
            <HomePage
              mode={mode} recognized={recognized} response={response} logs={logs} settings={settings}
              lastEngine={lastEngine} lastResult={lastResult} onlineStatus={onlineStatus} microphoneStatus={microphoneStatus}
              speechAvailable={speechAvailable} busy={busy} draft={draft} onDraft={setDraft}
              onSubmit={submitInput} onStart={() => startListening(false)} onPushStart={() => startListening(true)}
              onPushEnd={() => { recognitionRef.current?.stop(); }} onStop={stopAll} onNavigate={setPage}
            />
          )}
          {page === "LOG" && <LogPage logs={logs} onClear={() => setLogs([])} />}
          {page === "PROFILE" && <ProfilePage settings={settings} onChange={changeSettings} />}
          {page === "SETTINGS" && (
            <SettingsPage
              settings={settings} apiKey={apiKey} onlineStatus={onlineStatus} onlineMessage={onlineMessage}
              connectionCheck={connectionCheck} onKey={setApiKey} onChange={changeSettings} onTest={testConnection}
            />
          )}
        </section>
      </main>
      <footer className="copyright">FRIDAY / PERSONAL AI ASSISTANT <span>WHOLE CREDIT GOES TO ADITYA</span> © 2026 ADITYA</footer>
    </div>
  );
}

function HomePage(props: {
  mode: Mode; recognized: string; response: string; logs: Transcript[]; settings: FridaySettings;
  lastEngine: string; lastResult: string; onlineStatus: string; microphoneStatus: string; speechAvailable: boolean; busy: boolean;
  draft: string; onDraft: (value: string) => void; onSubmit: (event: FormEvent<HTMLFormElement>) => void;
  onStart: () => void; onPushStart: () => void; onPushEnd: () => void; onStop: () => void; onNavigate: (page: Page) => void;
}) {
  const { mode, recognized, response, logs, settings, lastEngine, lastResult, onlineStatus, microphoneStatus, speechAvailable, busy } = props;
  return (
    <div className="page home-page">
      <div className="page-intro">
        <div><p className="eyebrow">SYSTEM // 01 <span>LOCAL + CLOUD</span></p><h1>Intelligence, <em>at your command.</em></h1></div>
        <span className="clock-label"><i />{new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })} <b>IST</b></span>
      </div>

      <section className="core-stage" aria-label="FRIDAY voice control">
        <div className="core-wrap"><CoreGraphic mode={mode} /></div>
        <div className="core-readout">
          <span className={`mode-dot ${mode.toLowerCase()}`} /><span className="mode-word">{mode}</span>
          <span className="mode-rule" /><span className="engine-readout">{lastEngine === "NOT USED" ? "ENGINE STANDBY" : lastEngine}</span>
        </div>
        <div className={`waveform ${mode !== "READY" ? "active" : ""}`} aria-hidden="true">
          {waveHeights.map((height, index) => <i key={index} style={{ "--height": `${height}%`, "--delay": `${index * -37}ms` } as CSSProperties} />)}
        </div>
        <div className="voice-controls">
          <button className="control-button main-control" onClick={props.onStart} disabled={busy}>
            <span className="control-symbol"><MicIcon /></span><span>START LISTENING<small>{settings.automaticRecognition ? "ANDROID AUTO MODE" : "ANDROID MANUAL MODE"}</small></span>
          </button>
          <button className="control-button" onPointerDown={(event: PointerEvent<HTMLButtonElement>) => { event.currentTarget.setPointerCapture(event.pointerId); props.onPushStart(); }} onPointerUp={props.onPushEnd} onPointerCancel={props.onPushEnd} disabled={busy}>
            <span className="control-symbol hold-symbol"><span /></span><span>PUSH TO TALK<small>PRESS AND HOLD</small></span>
          </button>
          <button className="control-button stop-control" onClick={props.onStop}>
            <span className="control-symbol"><StopIcon /></span><span>STOP<small>VOICE / OUTPUT</small></span>
          </button>
        </div>
      </section>

      <section className="response-panel corner-frame">
        <div className="panel-heading"><span>ASSISTANT</span><span className={`result-label ${toneFor(lastResult)}`}>{lastResult}</span></div>
        <div className="response-grid">
          <div className="heard-block"><span className="field-label">HEARD</span><p>{recognized || <span className="empty-copy">No speech or text command received yet.</span>}</p></div>
          <div className="reply-block"><span className="field-label">RESPONSE <b>[{lastEngine}]</b></span><p>{response}</p></div>
        </div>
        <form className="command-form" onSubmit={props.onSubmit}>
          <input value={props.draft} onChange={(event) => props.onDraft(event.target.value)} placeholder="Type a command or question" aria-label="Type a command or question" />
          <button type="submit" disabled={busy}>SEND <ArrowIcon /></button>
        </form>
      </section>

      <div className="lower-grid">
        <section className="corner-frame recent-panel">
          <div className="panel-heading"><span>RECENT COMMANDS</span><button className="text-link" onClick={() => props.onNavigate("LOG")}>OPEN LOG <ArrowIcon /></button></div>
          {logs.length === 0 ? <p className="empty-copy">Received commands and real results will appear here.</p> : logs.slice(0, 3).map((entry) => (
            <div className="recent-entry" key={entry.id}>
              <span className="entry-mark">›</span><div><p>{entry.heard}</p><small>{entry.result} <b>/</b> {entry.engine}</small></div><time>{timeLabel(entry.time)}</time>
            </div>
          ))}
        </section>

        <section className="corner-frame status-panel">
          <div className="panel-heading"><span>SERVICE STATUS</span><span className="field-label">LIVE</span></div>
          <StatusLine label="RECOGNITION SERVICE" value={speechAvailable ? "AVAILABLE" : "UNAVAILABLE"} tone={speechAvailable ? "good" : "warn"} />
          <StatusLine label="MICROPHONE" value={microphoneStatus} tone={microphoneStatus === "LISTENING" || microphoneStatus === "READY" ? "good" : "muted"} />
          <StatusLine label="ONLINE AI" value={!settings.online ? "OFF" : onlineStatus === "CONNECTED" ? "CONNECTED" : "NOT TESTED"} tone={settings.online ? onlineStatus === "CONNECTED" ? "good" : "cyan" : "muted"} />
          <StatusLine label={`WAKE WORD (${settings.wakeWord || "FRIDAY"})`} value="NOT RUNNING" tone="warn" />
          <StatusLine label="ACCESSIBILITY" value="ANDROID APP ONLY" tone="muted" />
          <StatusLine label="LAST ACTION" value={lastResult} tone={toneFor(lastResult)} />
          <div className="browser-note">BROWSER COMPANION / ANDROID CONTROLS RUN IN THE NATIVE APK.</div>
        </section>
      </div>
    </div>
  );
}

function CoreGraphic({ mode }: { mode: Mode }) {
  const active = mode === "LISTENING" || mode === "SPEAKING" || mode === "THINKING";
  return (
    <svg className={`core-svg ${active ? "is-active" : ""}`} viewBox="0 0 360 360" role="img" aria-label={`FRIDAY core ${mode.toLowerCase()}`}>
      <defs>
        <radialGradient id="core-fill"><stop offset="0" stopColor="#00e0f7" stopOpacity=".24" /><stop offset=".6" stopColor="#168baf" stopOpacity=".08" /><stop offset="1" stopColor="#080d15" stopOpacity="0" /></radialGradient>
        <filter id="core-glow"><feGaussianBlur stdDeviation="3.2" result="blur" /><feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge></filter>
      </defs>
      <circle cx="180" cy="180" r="166" fill="url(#core-fill)" />
      <circle className="ring ring-outer" cx="180" cy="180" r="160" />
      <circle className="ring ring-thin" cx="180" cy="180" r="148" />
      <g className="ring-sweep" filter="url(#core-glow)"><circle className="sweep-one" cx="180" cy="180" r="154" /><circle className="sweep-two" cx="180" cy="180" r="142" /></g>
      <g className="core-ticks">
        {Array.from({ length: 64 }, (_, index) => {
          const angle = (index * Math.PI * 2) / 64;
          const major = index % 4 === 0;
          const radius = major ? 112 : 120;
          const x1 = 180 + Math.cos(angle) * radius;
          const y1 = 180 + Math.sin(angle) * radius;
          const x2 = 180 + Math.cos(angle) * (major ? 134 : 132);
          const y2 = 180 + Math.sin(angle) * (major ? 134 : 132);
          return <line key={index} x1={x1} y1={y1} x2={x2} y2={y2} className={major ? "tick major" : "tick"} />;
        })}
      </g>
      <circle className="core-center-ring" cx="180" cy="180" r="86" />
      <circle className="core-center" cx="180" cy="180" r="8" />
      <circle className="orbit-dot" cx="180" cy="24" r="3" />
    </svg>
  );
}

function StatusLine({ label, value, tone }: { label: string; value: string; tone: string }) {
  return <div className="status-line"><span className={`status-dot ${tone}`} /><span className="status-label">{label}</span><span className={`status-value ${tone}`}>{value}</span></div>;
}

function LogPage({ logs, onClear }: { logs: Transcript[]; onClear: () => void }) {
  return (
    <div className="page subpage">
      <PageHeading eyebrow="SYSTEM // 02" title="Command log" description="Recent input and actual local action results." />
      <section className="corner-frame log-page-panel">
        <div className="panel-heading"><span>{String(logs.length).padStart(2, "0")} RECORDS / LOCAL DEVICE</span><button className="text-link danger-link" onClick={onClear} disabled={!logs.length}>CLEAR HISTORY</button></div>
        {!logs.length ? <p className="empty-copy">Nothing has been recognized or typed into this session yet.</p> : logs.map((entry) => (
          <article className="log-record" key={entry.id}>
            <div className="record-top"><time>{new Date(entry.time).toLocaleString()}</time><span className={`result-label ${toneFor(entry.result)}`}>{entry.result}</span></div>
            <span className="field-label">HEARD</span><p>{entry.heard}</p>
            <span className="field-label">RESPONSE / {entry.engine}</span><p className="record-answer">{entry.response}</p>
          </article>
        ))}
      </section>
      <p className="footnote">Browser logs stay in this browser's local storage. Native Android logs remain in app storage.</p>
    </div>
  );
}

function ProfilePage({ settings, onChange }: { settings: FridaySettings; onChange: (patch: Partial<FridaySettings>) => void }) {
  return (
    <div className="page subpage">
      <PageHeading eyebrow="SYSTEM // 03" title="Profile" description="A more personal voice, without giving up local control." />
      <section className="corner-frame form-panel">
        <div className="panel-heading"><span>YOUR PREFERENCES</span><span className="field-label">SAVED LOCALLY</span></div>
        <Field label="PREFERRED NAME" value={settings.preferredName} placeholder="What should FRIDAY call you?" onChange={(preferredName) => onChange({ preferredName })} />
        <Field label="ASSISTANT NAME" value={settings.assistantName} placeholder="FRIDAY" onChange={(assistantName) => onChange({ assistantName })} />
        <SelectField label="LANGUAGE / RECOGNITION" value={settings.language} options={[{ label: "Hindi / Hinglish (India)", value: "hi-IN" }, { label: "English (India)", value: "en-IN" }]} onChange={(language) => onChange({ language: language as FridaySettings["language"] })} />
        <SelectField label="VOICE PREFERENCE" value={settings.voice} options={[{ label: "Automatic / system fallback", value: "AUTO" }, { label: "Hindi (if installed)", value: "hi-IN" }, { label: "English (India, if installed)", value: "en-IN" }]} onChange={(voice) => onChange({ voice: voice as FridaySettings["voice"] })} />
        <p className="form-note">Voice output uses the available browser speech synthesis engine here. Native FRIDAY uses Android TextToSpeech and its installed Hindi / English voices.</p>
      </section>
      <section className="about-copy">
        <span className="field-label">ABOUT</span>
        <h2>FRIDAY <span>—</span> Personal AI Assistant</h2>
        <p>Whole credit goes to Aditya.</p>
        <small>© 2026 Aditya. All rights reserved.</small>
      </section>
    </div>
  );
}

function SettingsPage(props: {
  settings: FridaySettings; apiKey: string; onlineStatus: string; onlineMessage: string; connectionCheck: boolean;
  onKey: (value: string) => void; onChange: (patch: Partial<FridaySettings>) => void; onTest: () => void;
}) {
  const { settings, apiKey, onlineStatus, onlineMessage, connectionCheck } = props;
  const setProvider = (provider: FridaySettings["provider"]) => props.onChange({
    provider,
    endpoint: provider === "Groq" ? "https://api.groq.com/openai/v1/chat/completions" : settings.endpoint,
  });
  return (
    <div className="page subpage settings-page">
      <PageHeading eyebrow="SYSTEM // 04" title="Settings" description="Provider configuration and transparent permissions." />
      <section className="corner-frame form-panel">
        <div className="panel-heading"><span>DEVICE ADMIN / PHONE LOCK</span><span className="result-label warn">NATIVE ANDROID ONLY</span></div>
        <p className="settings-copy">The Android app requests only the force-lock policy. Activation and deactivation are controlled from Android settings.</p>
        <div className="status-line"><span className="status-dot warn" /><span className="status-label">PHONE LOCK</span><span className="status-value warn">NOT AVAILABLE IN BROWSER</span></div>
      </section>

      <section className="corner-frame form-panel">
        <div className="panel-heading"><span>AI PROVIDER / OPTIONAL</span><span className={`result-label ${settings.online ? "good" : "muted"}`}>{settings.online ? "ENABLED" : "OFF"}</span></div>
        <ToggleRow title="ENABLE ONLINE AI" detail="Cloud chats go to the endpoint below. The provider's current free-tier limits apply." checked={settings.online} onChange={(online) => props.onChange({ online })} />
        <SelectField label="AI PROVIDER" value={settings.provider} options={[{ label: "Groq", value: "Groq" }, { label: "Custom OpenAI-compatible", value: "Custom OpenAI-compatible" }]} onChange={(value) => setProvider(value as FridaySettings["provider"])} />
        <Field label="API ENDPOINT" value={settings.endpoint} placeholder="https://api.groq.com/openai/v1/chat/completions" onChange={(endpoint) => props.onChange({ endpoint })} />
        <Field label="MODEL NAME" value={settings.model} placeholder="Enter a model supported by your provider" onChange={(model) => props.onChange({ model })} />
        <label className="field-wrap"><span>API KEY / MEMORY ONLY</span><input type="password" autoComplete="new-password" value={apiKey} onChange={(event) => props.onKey(event.target.value)} placeholder="Not stored by the browser companion" /></label>
        <p className="form-note">The browser companion keeps this key in component memory only; refresh clears it. Use the native Android app for Android Keystore-backed encrypted storage.</p>
        <div className="form-actions">
          <button className="outline-button" onClick={props.onTest} disabled={connectionCheck}>{connectionCheck ? "TESTING..." : "TEST CONNECTION"}</button>
          <a className="quiet-link" href="https://console.groq.com/keys" target="_blank" rel="noreferrer">GROQ KEY DASHBOARD <ArrowIcon /></a>
        </div>
        <div className="connection-result">
          <StatusLine label="CONNECTION" value={onlineStatus} tone={onlineStatus === "CONNECTED" ? "good" : onlineStatus === "FAILED" ? "bad" : onlineStatus === "TESTING" ? "cyan" : "muted"} />
          <p>{onlineMessage}</p>
        </div>
      </section>

      <section className="corner-frame form-panel">
        <div className="panel-heading"><span>VOICE / PRIVACY</span></div>
        <ToggleRow title="AUTOMATIC RECOGNITION" detail="The Android app restarts recognition only after you explicitly start a session." checked={settings.automaticRecognition} onChange={(automaticRecognition) => props.onChange({ automaticRecognition })} />
        <Field label="WAKE WORD PREFERENCE" value={settings.wakeWord} onChange={(wakeWord) => props.onChange({ wakeWord: wakeWord.slice(0, 32) || "FRIDAY" })} />
        <div className="status-line"><span className="status-dot warn" /><span className="status-label">LOCAL WAKE ENGINE</span><span className="status-value warn">NOT RUNNING</span></div>
        <p className="settings-copy">No always-on wake-word model is bundled. The preference does not leave your microphone open. Accessibility actions and device lock require the native Android APK.</p>
      </section>
      <p className="footnote">No key is logged, no unlimited API access is claimed, and this browser cannot perform Android automation.</p>
    </div>
  );
}

function Field({ label, value, placeholder, onChange }: { label: string; value: string; placeholder?: string; onChange: (value: string) => void }) {
  return <label className="field-wrap"><span>{label}</span><input value={value} onChange={(event) => onChange(event.target.value)} placeholder={placeholder} /></label>;
}

function SelectField({ label, value, options, onChange }: { label: string; value: string; options: Array<{ label: string; value: string }>; onChange: (value: string) => void }) {
  return (
    <label className="field-wrap"><span>{label}</span>
      <select value={value} onChange={(event) => onChange(event.target.value)}>
        {options.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
      </select>
    </label>
  );
}

function ToggleRow({ title, detail, checked, onChange }: { title: string; detail: string; checked: boolean; onChange: (checked: boolean) => void }) {
  return (
    <label className="toggle-row">
      <span><b>{title}</b><small>{detail}</small></span>
      <input type="checkbox" checked={checked} onChange={(event) => onChange(event.target.checked)} />
      <i aria-hidden="true"><b /></i>
    </label>
  );
}

function PageHeading({ eyebrow, title, description }: { eyebrow: string; title: string; description: string }) {
  return <div className="page-intro subpage-intro"><div><p className="eyebrow">{eyebrow}</p><h1>{title}<em>.</em></h1><p className="page-description">{description}</p></div></div>;
}

function MicIcon() {
  return <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><rect x="9" y="3" width="6" height="12" rx="3" /><path d="M5.5 11.5a6.5 6.5 0 0 0 13 0M12 18v3m-4 0h8" /></svg>;
}
function StopIcon() {
  return <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><rect x="6" y="6" width="12" height="12" rx="1" /></svg>;
}
function SettingsIcon() {
  return <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="3" /><path d="m19.4 15 .1.1a1.8 1.8 0 0 1-2.5 2.5l-.1-.1a1.8 1.8 0 0 0-3 .8v.2a1.8 1.8 0 0 1-3.6 0v-.2a1.8 1.8 0 0 0-3-.8l-.1.1a1.8 1.8 0 0 1-2.5-2.5l.1-.1a1.8 1.8 0 0 0-.8-3h-.2a1.8 1.8 0 0 1 0-3.6h.2a1.8 1.8 0 0 0 .8-3l-.1-.1a1.8 1.8 0 0 1 2.5-2.5l.1.1a1.8 1.8 0 0 0 3-.8v-.2a1.8 1.8 0 0 1 3.6 0v.2a1.8 1.8 0 0 0 3 .8l.1-.1a1.8 1.8 0 0 1 2.5 2.5l-.1.1a1.8 1.8 0 0 0 .8 3h.2a1.8 1.8 0 0 1 0 3.6h-.2a1.8 1.8 0 0 0-.8 3Z" transform="translate(1 1) scale(.92)" /></svg>;
}
function ArrowIcon() {
  return <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M3 10h13m-5-5 5 5-5 5" /></svg>;
}
