package com.aditya.friday.ui

import android.Manifest
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

@Composable
fun FridayApp(viewModel: FridayViewModel) {
    val state = viewModel.state
    var page by rememberSaveable { mutableStateOf(FridayPage.HOME) }
    var showStartup by rememberSaveable { mutableStateOf(true) }
    var pendingMicAction by remember { mutableStateOf(false) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        viewModel.refreshStatuses()
        if (granted) {
            if (pendingMicAction) viewModel.startPushToTalk() else viewModel.startListening()
        } else viewModel.microphonePermissionDenied()
        pendingMicAction = false
    }

    BackHandler(enabled = !showStartup && page != FridayPage.HOME) { page = FridayPage.HOME }

    Box(Modifier.fillMaxSize().background(FridayBackground)) {
        if (showStartup) {
            FridaySplashScreen(onLoadingComplete = { showStartup = false })
        } else {
            Column(Modifier.fillMaxSize()) {
                Box(
                    Modifier.weight(1f)
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp),
                ) {
                    AnimatedContent(
                        targetState = page,
                        transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(110)) },
                        label = "friday-pages",
                    ) { target ->
                        when (target) {
                            FridayPage.HOME -> HomeScreen(
                                state = state,
                                onStartListening = {
                                    if (ContextCompat.checkSelfPermission(
                                            viewModel.getApplication(),
                                            Manifest.permission.RECORD_AUDIO,
                                        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                                    ) viewModel.startListening() else {
                                        pendingMicAction = false
                                        permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    }
                                },
                                onStartPushToTalk = {
                                    if (ContextCompat.checkSelfPermission(
                                            viewModel.getApplication(),
                                            Manifest.permission.RECORD_AUDIO,
                                        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                                    ) viewModel.startPushToTalk() else {
                                        pendingMicAction = true
                                        permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    }
                                },
                                onReleasePushToTalk = viewModel::releasePushToTalk,
                                onStop = viewModel::stop,
                                onSubmit = viewModel::submitText,
                                onOpenAccessibility = viewModel::openAccessibilitySetup,
                            )
                            FridayPage.LOG -> LogScreen(state)
                            FridayPage.PROFILE -> ProfileScreen(state.settings, viewModel::updateSettings)
                            FridayPage.SETTINGS -> SettingsScreen(
                                state = state,
                                onUpdate = viewModel::updateSettings,
                                onSaveKey = viewModel::saveApiKey,
                                onRemoveKey = viewModel::removeApiKey,
                                onTestConnection = viewModel::testConnection,
                                onOpenAccessibility = viewModel::openAccessibilitySetup,
                                onConfigureDeviceAdmin = viewModel::configureDeviceAdmin,
                                onOpenProviderWebsite = viewModel::openProviderWebsite,
                            )
                        }
                    }
                }
                FridayBottomNavigation(selected = page, onSelect = { page = it })
            }
        }
    }
}

@Composable
private fun FridayBottomNavigation(selected: FridayPage, onSelect: (FridayPage) -> Unit) {
    val pages = listOf(FridayPage.HOME, FridayPage.LOG, FridayPage.PROFILE, FridayPage.SETTINGS)
    Row(
        Modifier.fillMaxWidth()
            .background(FridaySurface)
            .border(width = 0.6.dp, color = FridayCyan.copy(alpha = 0.20f))
            .navigationBarsPadding()
            .height(59.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        pages.forEach { item ->
            val active = selected == item
            Column(
                Modifier.weight(1f)
                    .fillMaxSize()
                    .clickable { onSelect(item) }
                    .semantics { role = Role.Tab }
                    .padding(top = 9.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Top,
            ) {
                Text(
                    item.label,
                    color = if (active) FridayCyan else FridayMuted,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    letterSpacing = 1.4.sp,
                    fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
                )
                Spacer(Modifier.height(7.dp))
                Box(Modifier.width(if (active) 20.dp else 4.dp).height(2.dp).background(if (active) FridayCyan else FridayMuted.copy(alpha = 0.4f)))
            }
        }
    }
}

private enum class FridayPage(val label: String) {
    HOME("HOME"),
    LOG("LOG"),
    PROFILE("PROFILE"),
    SETTINGS("SETTINGS"),
}