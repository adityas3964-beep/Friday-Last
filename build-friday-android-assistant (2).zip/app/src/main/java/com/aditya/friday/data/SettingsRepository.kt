package com.aditya.friday.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class SettingsRepository(context: Context) {
    private val preferences = context.getSharedPreferences("friday_settings", Context.MODE_PRIVATE)

    fun loadSettings(): FridaySettings = FridaySettings(
        onlineAiEnabled = preferences.getBoolean("online_ai_enabled", false),
        automaticRecognition = preferences.getBoolean("automatic_recognition", true),
        provider = preferences.getString("provider", "Groq") ?: "Groq",
        endpoint = preferences.getString(
            "endpoint",
            "https://api.groq.com/openai/v1/chat/completions",
        ) ?: "https://api.groq.com/openai/v1/chat/completions",
        modelName = preferences.getString("model_name", "") ?: "",
        preferredName = preferences.getString("preferred_name", "") ?: "",
        assistantName = preferences.getString("assistant_name", "FRIDAY") ?: "FRIDAY",
        language = preferences.getString("language", "hi-IN") ?: "hi-IN",
        voiceLocale = preferences.getString("voice_locale", "AUTO") ?: "AUTO",
        wakeWord = preferences.getString("wake_word", "FRIDAY") ?: "FRIDAY",
    )

    fun saveSettings(settings: FridaySettings) {
        preferences.edit()
            .putBoolean("online_ai_enabled", settings.onlineAiEnabled)
            .putBoolean("automatic_recognition", settings.automaticRecognition)
            .putString("provider", settings.provider)
            .putString("endpoint", settings.endpoint)
            .putString("model_name", settings.modelName)
            .putString("preferred_name", settings.preferredName)
            .putString("assistant_name", settings.assistantName)
            .putString("language", settings.language)
            .putString("voice_locale", settings.voiceLocale)
            .putString("wake_word", settings.wakeWord)
            .apply()
    }

    fun hasApiKey(): Boolean = preferences.getString("encrypted_api_key", null) != null

    fun saveEncryptedApiKey(encryptedValue: String) {
        preferences.edit().putString("encrypted_api_key", encryptedValue).apply()
    }

    fun readEncryptedApiKey(): String? = preferences.getString("encrypted_api_key", null)

    fun clearEncryptedApiKey() {
        preferences.edit().remove("encrypted_api_key").apply()
    }

    fun loadRecentLogs(): List<CommandLogEntry> {
        val json = preferences.getString("recent_logs", "[]") ?: "[]"
        return runCatching {
            val array = JSONArray(json)
            (0 until array.length()).map { index ->
                val entry = array.getJSONObject(index)
                CommandLogEntry(
                    timestamp = entry.optLong("timestamp"),
                    recognized = entry.optString("recognized"),
                    response = entry.optString("response"),
                    engine = entry.optString("engine"),
                    result = entry.optString("result"),
                )
            }
        }.getOrDefault(emptyList())
    }

    fun appendLog(entry: CommandLogEntry) {
        val logs = loadRecentLogs().toMutableList()
        logs.add(0, entry)
        val array = JSONArray()
        logs.take(30).forEach { item ->
            array.put(
                JSONObject()
                    .put("timestamp", item.timestamp)
                    .put("recognized", item.recognized)
                    .put("response", item.response)
                    .put("engine", item.engine)
                    .put("result", item.result),
            )
        }
        preferences.edit().putString("recent_logs", array.toString()).apply()
    }
}