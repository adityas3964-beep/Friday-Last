package com.aditya.friday.commands

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import com.aditya.friday.data.ExecutionResult
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.Locale

class AppLauncher(private val context: Context) {
    fun openApp(requestedName: String): ExecutionResult {
        val name = requestedName.trim().take(80)
        val aliases = packageAliases(name)
        val packageIntent = aliases.firstNotNullOfOrNull { packageName ->
            runCatching { context.packageManager.getLaunchIntentForPackage(packageName) }.getOrNull()
        }
        val matchingActivity = packageIntent ?: findLauncherIntent(name)
        return launch(matchingActivity, "${name} is not installed or Android did not expose a launch activity.")
    }

    fun openSettings(target: SettingsTarget): ExecutionResult {
        val action = when (target) {
            SettingsTarget.GENERAL -> Settings.ACTION_SETTINGS
            SettingsTarget.WIFI -> Settings.ACTION_WIFI_SETTINGS
            SettingsTarget.BLUETOOTH -> Settings.ACTION_BLUETOOTH_SETTINGS
            SettingsTarget.DISPLAY -> Settings.ACTION_DISPLAY_SETTINGS
        }
        val label = when (target) {
            SettingsTarget.GENERAL -> "Phone settings"
            SettingsTarget.WIFI -> "Wi-Fi settings"
            SettingsTarget.BLUETOOTH -> "Bluetooth settings"
            SettingsTarget.DISPLAY -> "Display settings"
        }
        return launch(Intent(action), "$label could not be opened on this device.")
    }

    fun searchWeb(query: String): ExecutionResult {
        val safeQuery = query.trim().take(500)
        if (safeQuery.isBlank()) return ExecutionResult("What should I search for?", false, "ACTION FAILED")
        val encoded = URLEncoder.encode(safeQuery, StandardCharsets.UTF_8.name())
        return launch(
            Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$encoded")),
            "No browser is available to search for that.",
        )
    }

    fun openWhatsApp(): ExecutionResult {
        val intent = packageAliases("WhatsApp").firstNotNullOfOrNull { packageName ->
            runCatching { context.packageManager.getLaunchIntentForPackage(packageName) }.getOrNull()
        }
        return launch(intent, "WhatsApp is not installed or could not be opened.")
    }

    fun shareConfirmedMessage(recipient: String, message: String): ExecutionResult {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, message)
            setPackage("com.whatsapp")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            ExecutionResult(
                "WhatsApp opened with the confirmed text. Choose $recipient and tap Send yourself; no message was sent automatically.",
                true,
                "MANUAL SEND REQUIRED",
            )
        } catch (_: ActivityNotFoundException) {
            ExecutionResult("WhatsApp could not open the message handoff. Nothing was sent.", false, "ACTION FAILED")
        } catch (_: SecurityException) {
            ExecutionResult("Android blocked the WhatsApp handoff. Nothing was sent.", false, "ACTION FAILED")
        }
    }

    fun isWhatsAppInstalled(): Boolean = packageAliases("WhatsApp").any { packageName ->
        runCatching { context.packageManager.getPackageInfo(packageName, 0) }.isSuccess
    }

    private fun launch(intent: Intent?, failureMessage: String): ExecutionResult {
        if (intent == null) return ExecutionResult(failureMessage, false, "ACTION FAILED")
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            ExecutionResult("Opened ${intent.resolveLabel()}.", true, "ACTION SUCCESS")
        } catch (_: ActivityNotFoundException) {
            ExecutionResult(failureMessage, false, "ACTION FAILED")
        } catch (_: SecurityException) {
            ExecutionResult("Android denied that app launch. Check app availability and permissions.", false, "ACTION FAILED")
        }
    }

    private fun findLauncherIntent(requestedName: String): Intent? {
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val activities = runCatching {
            context.packageManager.queryIntentActivities(launcher, PackageManager.MATCH_ALL)
        }.getOrDefault(emptyList())
        val request = requestedName.lowercase(Locale.ROOT)
        val resolved = activities.firstOrNull { info ->
            val label = runCatching { info.loadLabel(context.packageManager).toString() }
                .getOrDefault("").lowercase(Locale.ROOT)
            label == request || label.contains(request) || request.contains(label) && label.length > 2
        } ?: return null
        return Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).apply {
            setClassName(resolved.activityInfo.packageName, resolved.activityInfo.name)
        }
    }

    private fun packageAliases(name: String): List<String> = when (name.lowercase(Locale.ROOT)) {
        "whatsapp" -> listOf("com.whatsapp", "com.whatsapp.w4b")
        "youtube" -> listOf("com.google.android.youtube")
        "chrome" -> listOf("com.android.chrome")
        "gallery", "photos" -> listOf("com.google.android.apps.photos", "com.android.gallery3d", "com.sec.android.gallery3d")
        "camera" -> listOf("com.google.android.GoogleCamera", "com.android.camera2", "com.sec.android.app.camera")
        "calculator" -> listOf("com.google.android.calculator", "com.android.calculator2", "com.sec.android.app.popupcalculator")
        "phone", "dialer" -> listOf("com.google.android.dialer", "com.android.dialer")
        "settings" -> listOf("com.android.settings")
        else -> emptyList()
    }

    private fun Intent.resolveLabel(): String = when (action) {
        Settings.ACTION_SETTINGS -> "phone settings"
        Settings.ACTION_WIFI_SETTINGS -> "Wi-Fi settings"
        Settings.ACTION_BLUETOOTH_SETTINGS -> "Bluetooth settings"
        Settings.ACTION_DISPLAY_SETTINGS -> "display settings"
        Intent.ACTION_VIEW -> "the requested page"
        else -> "the requested app"
    }
}