package com.aditya.friday.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

@Composable
fun HudPanel(
    title: String,
    modifier: Modifier = Modifier,
    content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit,
) {
    val cornerColor = FridayCyan.copy(alpha = 0.92f)
    Box(
        modifier
            .fillMaxWidth()
            .background(FridaySurface.copy(alpha = 0.86f))
            .border(1.dp, FridayCyan.copy(alpha = 0.32f), RoundedCornerShape(3.dp)),
    ) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 16.dp)) {
            Text(
                text = title.uppercase(),
                color = FridayCyan,
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                letterSpacing = 2.3.sp,
                fontWeight = FontWeight.Medium,
            )
            Spacer(Modifier.height(12.dp))
            content()
        }
        Canvas(Modifier.matchParentSize()) {
            val length = 14.dp.toPx()
            val stroke = 2.dp.toPx()
            drawLine(cornerColor, androidx.compose.ui.geometry.Offset(0f, 1f), androidx.compose.ui.geometry.Offset(length, 1f), stroke)
            drawLine(cornerColor, androidx.compose.ui.geometry.Offset(1f, 0f), androidx.compose.ui.geometry.Offset(1f, length), stroke)
            drawLine(cornerColor, androidx.compose.ui.geometry.Offset(size.width - length, 1f), androidx.compose.ui.geometry.Offset(size.width, 1f), stroke)
            drawLine(cornerColor, androidx.compose.ui.geometry.Offset(size.width - 1f, 0f), androidx.compose.ui.geometry.Offset(size.width - 1f, length), stroke)
            drawLine(cornerColor, androidx.compose.ui.geometry.Offset(0f, size.height - 1f), androidx.compose.ui.geometry.Offset(length, size.height - 1f), stroke)
            drawLine(cornerColor, androidx.compose.ui.geometry.Offset(1f, size.height - length), androidx.compose.ui.geometry.Offset(1f, size.height), stroke)
            drawLine(cornerColor, androidx.compose.ui.geometry.Offset(size.width - length, size.height - 1f), androidx.compose.ui.geometry.Offset(size.width, size.height - 1f), stroke)
            drawLine(cornerColor, androidx.compose.ui.geometry.Offset(size.width - 1f, size.height - length), androidx.compose.ui.geometry.Offset(size.width - 1f, size.height), stroke)
        }
    }
}

@Composable
fun HudButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    height: Dp = 54.dp,
    danger: Boolean = false,
    primary: Boolean = false,
    enabled: Boolean = true,
) {
    val color = if (danger) FridayRed else if (primary) FridayCyan else FridayMuted
    val shape = RoundedCornerShape(3.dp)
    Box(
        modifier = modifier
            .height(height)
            .clip(shape)
            .background(if (primary) FridayCyan.copy(alpha = 0.10f) else FridaySurfaceRaised)
            .border(1.dp, color.copy(alpha = if (enabled) 0.9f else 0.3f), shape)
            .clickable(enabled = enabled, onClick = onClick)
            .semantics { role = Role.Button }
            .padding(horizontal = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label.uppercase(),
            color = color.copy(alpha = if (enabled) 1f else 0.5f),
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
            letterSpacing = 1.5.sp,
            lineHeight = 16.sp,
            textAlign = TextAlign.Center,
            fontWeight = FontWeight.SemiBold,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
fun PressHoldButton(
    label: String,
    onPress: () -> Unit,
    onRelease: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(3.dp)
    Box(
        modifier = modifier
            .height(58.dp)
            .clip(shape)
            .background(FridaySurfaceRaised)
            .border(1.dp, FridayMuted.copy(alpha = 0.88f), shape)
            .pointerInput(onPress, onRelease) {
                detectTapGestures(onPress = {
                    onPress()
                    try {
                        awaitRelease()
                    } finally {
                        onRelease()
                    }
                })
            }
            .semantics { role = Role.Button }
            .padding(horizontal = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label.uppercase(),
            color = FridayText,
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
            letterSpacing = 1.6.sp,
            textAlign = TextAlign.Center,
            fontWeight = FontWeight.SemiBold,
        )
    }
}

@Composable
fun FridayTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    placeholder: String = "",
    singleLine: Boolean = true,
    password: Boolean = false,
    keyboardType: KeyboardType = KeyboardType.Text,
    minLines: Int = 1,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier.fillMaxWidth(),
        label = { Text(label, color = FridayMuted, fontFamily = FontFamily.Monospace, fontSize = 12.sp) },
        placeholder = {
            if (placeholder.isNotBlank()) Text(placeholder, color = FridayMuted.copy(alpha = 0.65f), fontSize = 13.sp)
        },
        singleLine = singleLine,
        minLines = minLines,
        visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        textStyle = TextStyle(
            color = FridayText,
            fontFamily = FontFamily.Monospace,
            fontSize = 14.sp,
        ),
        shape = RoundedCornerShape(3.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = FridayCyan,
            unfocusedBorderColor = FridayCyan.copy(alpha = 0.36f),
            focusedLabelColor = FridayCyan,
            cursorColor = FridayCyan,
            focusedContainerColor = FridayBackground.copy(alpha = 0.8f),
            unfocusedContainerColor = FridayBackground.copy(alpha = 0.8f),
        ),
    )
}

@Composable
fun PreferenceSwitch(
    title: String,
    subtitle: String? = null,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth().clickable { onCheckedChange(!checked) }.padding(vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title.uppercase(), color = FridayText, fontFamily = FontFamily.Monospace, fontSize = 12.sp, letterSpacing = 1.2.sp)
            if (subtitle != null) {
                Spacer(Modifier.height(3.dp))
                Text(subtitle, color = FridayMuted, fontSize = 11.sp, lineHeight = 16.sp)
            }
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = FridayBackground,
                checkedTrackColor = FridayCyan,
                checkedBorderColor = FridayCyan,
                uncheckedThumbColor = FridayMuted,
                uncheckedTrackColor = FridaySurfaceRaised,
                uncheckedBorderColor = FridayMuted,
            ),
        )
    }
}

@Composable
fun StatusRow(label: String, value: String, tone: StatusTone, modifier: Modifier = Modifier) {
    val color = when (tone) {
        StatusTone.GOOD -> FridayGreen
        StatusTone.WARN -> FridayAmber
        StatusTone.BAD -> FridayRed
        StatusTone.NEUTRAL -> FridayMuted
        StatusTone.CYAN -> FridayCyan
    }
    Row(
        modifier = modifier.fillMaxWidth().padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Canvas(Modifier.size(8.dp)) { drawCircle(color) }
        Text(
            label.uppercase(),
            modifier = Modifier.weight(1f).padding(start = 10.dp),
            color = FridayMuted,
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp,
            letterSpacing = 1.0.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Text(
            value.uppercase(),
            color = color,
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp,
            letterSpacing = 0.7.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
        )
    }
}

enum class StatusTone { GOOD, WARN, BAD, NEUTRAL, CYAN }

@Composable
fun CoreOrb(mode: String, modifier: Modifier = Modifier) {
    val active = mode in setOf("LISTENING", "THINKING", "SPEAKING")
    val transition = rememberInfiniteTransition(label = "core")
    val pulse by transition.animateFloat(
        initialValue = 0.97f,
        targetValue = 1.03f,
        animationSpec = infiniteRepeatable(tween(1500), RepeatMode.Reverse),
        label = "pulse",
    )
    val rotation by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(18000, easing = androidx.compose.animation.core.LinearEasing)),
        label = "ring-rotation",
    )
    val glow = if (active) FridayCyan else FridayBlue
    Canvas(modifier) {
        val center = androidx.compose.ui.geometry.Offset(size.width / 2f, size.height / 2f)
        val radius = min(size.width, size.height) * 0.45f * pulse
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(FridayCyan.copy(alpha = if (active) 0.23f else 0.12f), FridayBlue.copy(alpha = 0.04f), androidx.compose.ui.graphics.Color.Transparent),
                center = center,
                radius = radius,
            ),
            radius = radius,
            center = center,
        )
        drawCircle(glow.copy(alpha = 0.28f), radius * 0.98f, center, style = Stroke(1.1.dp.toPx()))
        drawCircle(FridayBlue.copy(alpha = 0.55f), radius * 0.88f, center, style = Stroke(0.8.dp.toPx()))
        rotate(rotation, pivot = center) {
            drawArc(
                color = FridayCyan,
                startAngle = 206f,
                sweepAngle = 78f,
                useCenter = false,
                topLeft = androidx.compose.ui.geometry.Offset(center.x - radius * 0.98f, center.y - radius * 0.98f),
                size = androidx.compose.ui.geometry.Size(radius * 1.96f, radius * 1.96f),
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round),
            )
            drawArc(
                color = FridayCyan.copy(alpha = 0.82f),
                startAngle = 24f,
                sweepAngle = 34f,
                useCenter = false,
                topLeft = androidx.compose.ui.geometry.Offset(center.x - radius * 0.91f, center.y - radius * 0.91f),
                size = androidx.compose.ui.geometry.Size(radius * 1.82f, radius * 1.82f),
                style = Stroke(width = 2.2.dp.toPx(), cap = StrokeCap.Round),
            )
        }
        val tickCount = 64
        for (index in 0 until tickCount) {
            val angle = index * (2.0 * PI / tickCount)
            val longTick = index % 4 == 0
            val inner = radius * if (longTick) 0.63f else 0.69f
            val outer = radius * 0.76f
            val start = androidx.compose.ui.geometry.Offset(center.x + cos(angle).toFloat() * inner, center.y + sin(angle).toFloat() * inner)
            val end = androidx.compose.ui.geometry.Offset(center.x + cos(angle).toFloat() * outer, center.y + sin(angle).toFloat() * outer)
            drawLine(
                color = if (longTick) FridayCyan.copy(alpha = 0.9f) else FridayBlue.copy(alpha = 0.74f),
                start = start,
                end = end,
                strokeWidth = if (longTick) 2.3.dp.toPx() else 1.1.dp.toPx(),
                cap = StrokeCap.Round,
            )
        }
        drawCircle(
            brush = Brush.radialGradient(listOf(FridayCyan.copy(alpha = 0.36f), FridayBlue.copy(alpha = 0.18f), FridaySurface), center, radius * 0.54f),
            radius = radius * 0.46f,
            center = center,
        )
        drawCircle(FridayCyan.copy(alpha = 0.9f), radius * 0.46f, center, style = Stroke(1.2.dp.toPx()))
        drawCircle(FridayCyan, radius * 0.08f, center)
        drawCircle(FridayCyan.copy(alpha = 0.24f), radius * 0.18f, center, style = Stroke(1.dp.toPx()))
    }
}

@Composable
fun SignalWaveform(active: Boolean, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "signal")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2.0 * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(1600, easing = androidx.compose.animation.core.LinearEasing)),
        label = "signal-phase",
    )
    Canvas(modifier) {
        val bars = 39
        val gap = size.width / (bars * 1.65f)
        val stroke = gap * 0.33f
        val total = (bars - 1) * gap
        val startX = (size.width - total) / 2f
        val mid = size.height / 2f
        for (i in 0 until bars) {
            val wave = (sin(phase + i * 0.72f) + 1f) / 2f
            val envelope = 0.22f + 0.78f * kotlin.math.abs(sin(i * 0.19f + 0.5f))
            val base = if (active) 0.18f + wave * 0.8f else 0.2f + 0.54f * envelope
            val barHeight = (size.height * base).coerceIn(5.dp.toPx(), size.height * 0.92f)
            val x = startX + i * gap
            drawLine(
                color = FridayCyan.copy(alpha = if (active) 0.58f + wave * 0.42f else 0.58f),
                start = androidx.compose.ui.geometry.Offset(x, mid - barHeight / 2f),
                end = androidx.compose.ui.geometry.Offset(x, mid + barHeight / 2f),
                strokeWidth = stroke,
                cap = StrokeCap.Round,
            )
        }
    }
}

@Composable
fun FieldCaption(text: String, modifier: Modifier = Modifier) {
    Text(
        text.uppercase(),
        modifier = modifier,
        color = FridayMuted,
        fontFamily = FontFamily.Monospace,
        fontSize = 10.sp,
        letterSpacing = 1.5.sp,
    )
}

@Composable
fun BodyCopy(text: String, modifier: Modifier = Modifier, color: androidx.compose.ui.graphics.Color = FridayMuted) {
    Text(
        text,
        modifier = modifier,
        color = color,
        fontFamily = FontFamily.Monospace,
        fontSize = 12.sp,
        lineHeight = 17.sp,
    )
}

@Composable
fun SmallToggle(checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Switch(
        checked = checked,
        onCheckedChange = onCheckedChange,
        colors = SwitchDefaults.colors(checkedThumbColor = FridayBackground, checkedTrackColor = FridayCyan),
    )
}