package com.aditya.friday.commands

import com.aditya.friday.data.ConversationTurn
import com.aditya.friday.data.WhatsAppDraft

class ConversationContextManager {
    var selectedRecipient: String? = null
        private set
    var currentApp: String? = null
        private set
    var previousMessage: String? = null
        private set
    var pendingDraft: WhatsAppDraft? = null
        private set
    private val turns = mutableListOf<ConversationTurn>()

    fun selectRecipient(name: String) {
        selectedRecipient = name.trim().takeIf(String::isNotBlank)
    }

    fun setCurrentApp(name: String?) {
        currentApp = name
    }

    fun stageMessage(draft: WhatsAppDraft) {
        pendingDraft = draft
        selectedRecipient = draft.recipient
        previousMessage = draft.message
    }

    fun takePendingMessage(): WhatsAppDraft? = pendingDraft.also { pendingDraft = null }

    fun clearPendingMessage() {
        pendingDraft = null
    }

    fun addTurn(role: String, content: String) {
        if (content.isBlank()) return
        turns.add(ConversationTurn(role, content.take(1200)))
        while (turns.size > 12) turns.removeAt(0)
    }

    fun recentTurns(): List<ConversationTurn> = turns.toList()
}