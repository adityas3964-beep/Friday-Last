package com.aditya.friday.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.material3.Text
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

@Composable
fun FridaySplashScreen(onLoadingComplete: () -> Unit) {
    val progress = remember { Animatable(0f) }
    val latestOnComplete by rememberUpdatedState(onLoadingComplete)

    LaunchedEffect(Unit) {
        progress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 2_500, easing = LinearEasing),
        )
        latestOnComplete()
    }

    BoxWithConstraints(
        modifier = Modifier.fillMaxSize().background(FridayBackground),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) { drawHudGrid() }

        val coreDiameter = minOf(maxWidth * 0.68f, maxHeight * 0.34f, 250.dp).coerceAtLeast(128.dp)
        val titleSize = (maxWidth.value * 0.095f).coerceIn(26f, 38f).sp
        val titleSpacing = (maxWidth.value * 0.012f).coerceIn(2f, 4.2f).sp
        val subtitleSize = (maxWidth.value * 0.023f).coerceIn(5.6f, 7.8f).sp

        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Text(
                text = "F.R.I.D.A.Y.",
                color = FridayCyan,
                fontFamily = FontFamily.Monospace,
                fontSize = titleSize,
                letterSpacing = titleSpacing,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                style = TextStyle(shadow = Shadow(color = FridayCyan.copy(alpha = 0.9f), blurRadius = 24f)),
            )
            Spacer(Modifier.height(7.dp))
            Text(
                text = "FEMALE REPLACEMENT INTELLIGENT DIGITAL ASSISTANT YOUTH",
                modifier = Modifier.fillMaxWidth(),
                color = FridayMuted.copy(alpha = 0.93f),
                fontFamily = FontFamily.Monospace,
                fontSize = subtitleSize,
                letterSpacing = 0.55.sp,
                textAlign = TextAlign.Center,
                maxLines = 1,
            )
            Spacer(Modifier.height(24.dp))
            RadarReactor(Modifier.size(coreDiameter))
            Spacer(Modifier.height(18.dp))
            Text(
                text = "CALIBRATING...",
                color = FridayCyan,
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                letterSpacing = 1.9.sp,
                style = TextStyle(shadow = Shadow(color = FridayCyan.copy(alpha = 0.72f), blurRadius = 14f)),
            )
            Spacer(Modifier.height(23.dp))
            Box(
                Modifier.fillMaxWidth().height(3.dp)
                    .background(FridayCyan.copy(alpha = 0.16f), CircleShape),
            ) {
                Box(
                    Modifier.fillMaxWidth(progress.value.coerceIn(0f, 1f)).height(3.dp)
                        .background(Brush.horizontalGradient(listOf(FridayCyan, FridayBlue)), CircleShape),
                )
            }
            Text(
                text = "${(progress.value * 100f).toInt().coerceIn(0, 100)}%",
                modifier = Modifier.padding(top = 8.dp),
                color = FridayMuted,
                fontFamily = FontFamily.Monospace,
                fontSize = 9.sp,
                letterSpacing = 0.8.sp,
            )
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                repeat(5) { index ->
                    CalibrationDot(index = index, progress = progress.value)
                }
            }
        }
    }
}

@Composable
private fun RadarReactor(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "friday-radar")
    val rotation by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(durationMillis = 8_500, easing = LinearEasing)),
        label = "outer-radar-rotation",
    )
    val innerRotation by transition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(tween(durationMillis = 13_000, easing = LinearEasing)),
        label = "inner-radar-rotation",
    )
    val pulse by transition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(tween(1_250), repeatMode = RepeatMode.Reverse),
        label = "reactor-pulse",
    )

    Canvas(modifier) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val radius = min(size.width, size.height) * 0.46f
        val glowRadius = radius * pulse

        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(FridayCyan.copy(alpha = 0.18f), FridayBlue.copy(alpha = 0.06f), Color.Transparent),
                center = center,
                radius = glowRadius,
            ),
            radius = glowRadius,
            center = center,
        )
        drawCircle(FridayCyan.copy(alpha = 0.38f), radius * 0.98f, center, style = Stroke(1.dp.toPx()))
        drawCircle(FridayBlue.copy(alpha = 0.47f), radius * 0.87f, center, style = Stroke(0.8.dp.toPx()))
        drawCircle(FridayCyan.copy(alpha = 0.24f), radius * 0.62f, center, style = Stroke(1.dp.toPx()))

        rotate(rotation, pivot = center) {
            drawArc(
                color = FridayCyan,
                startAngle = -70f,
                sweepAngle = 91f,
                useCenter = false,
                topLeft = Offset(center.x - radius * 0.98f, center.y - radius * 0.98f),
                size = Size(radius * 1.96f, radius * 1.96f),
                style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round),
            )
            drawArc(
                color = FridayCyan.copy(alpha = 0.52f),
                startAngle = 119f,
                sweepAngle = 23f,
                useCenter = false,
                topLeft = Offset(center.x - radius * 0.98f, center.y - radius * 0.98f),
                size = Size(radius * 1.96f, radius * 1.96f),
                style = Stroke(width = 1.dp.toPx(), cap = StrokeCap.Round),
            )
        }
        rotate(innerRotation, pivot = center) {
            drawArc(
                color = FridayBlue.copy(alpha = 0.9f),
                startAngle = 205f,
                sweepAngle = 75f,
                useCenter = false,
                topLeft = Offset(center.x - radius * 0.72f, center.y - radius * 0.72f),
                size = Size(radius * 1.44f, radius * 1.44f),
                style = Stroke(width = 1.7.dp.toPx(), cap = StrokeCap.Round),
            )
        }

        repeat(48) { index ->
            val angle = index * (2.0 * PI / 48.0)
            val major = index % 4 == 0
            val inner = radius * if (major) 0.67f else 0.73f
            val outer = radius * 0.81f
            drawLine(
                color = if (major) FridayCyan.copy(alpha = 0.95f) else FridayBlue.copy(alpha = 0.74f),
                start = Offset(center.x + cos(angle).toFloat() * inner, center.y + sin(angle).toFloat() * inner),
                end = Offset(center.x + cos(angle).toFloat() * outer, center.y + sin(angle).toFloat() * outer),
                strokeWidth = if (major) 2.dp.toPx() else 1.dp.toPx(),
                cap = StrokeCap.Round,
            )
        }

        drawCircle(FridayCyan.copy(alpha = 0.72f), radius * 0.33f, center, style = Stroke(1.2.dp.toPx()))
        drawCircle(FridayBlue.copy(alpha = 0.58f), radius * 0.22f, center, style = Stroke(0.8.dp.toPx()))
        val reticle = radius * 0.14f
        drawLine(FridayCyan.copy(alpha = 0.42f), Offset(center.x - reticle, center.y), Offset(center.x + reticle, center.y), 0.8.dp.toPx())
        drawLine(FridayCyan.copy(alpha = 0.42f), Offset(center.x, center.y - reticle), Offset(center.x, center.y + reticle), 0.8.dp.toPx())
        drawCircle(FridayCyan.copy(alpha = 0.28f), radius * 0.09f, center, style = Stroke(1.dp.toPx()))
        drawCircle(FridayCyan, radius * 0.035f, center)
    }
}

@Composable
private fun CalibrationDot(index: Int, progress: Float) {
    val active = progress >= (index + 1) / 5f
    val transition = rememberInfiniteTransition(label = "calibration-dot-$index")
    val alpha by transition.animateFloat(
        initialValue = 0.24f,
        targetValue = if (active) 0.95f else 0.34f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 480 + index * 85, delayMillis = index * 70),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "dot-alpha-$index",
    )
    Box(
        Modifier.size(if (active) 5.dp else 4.dp)
            .background(FridayCyan.copy(alpha = alpha), CircleShape),
    )
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawHudGrid() {
    val step = 18.dp.toPx()
    val gridColor = FridayCyan.copy(alpha = 0.035f)
    var x = 0f
    while (x < size.width) {
        drawLine(gridColor, Offset(x, 0f), Offset(x, size.height), 0.6.dp.toPx())
        x += step
    }
    var y = 0f
    while (y < size.height) {
        drawLine(gridColor, Offset(0f, y), Offset(size.width, y), 0.6.dp.toPx())
        y += step
    }

    val margin = 14.dp.toPx()
    val bracket = 28.dp.toPx()
    val stroke = 1.dp.toPx()
    val accent = FridayCyan.copy(alpha = 0.24f)
    drawLine(accent, Offset(margin, margin), Offset(margin + bracket, margin), stroke)
    drawLine(accent, Offset(margin, margin), Offset(margin, margin + bracket), stroke)
    drawLine(accent, Offset(size.width - margin - bracket, margin), Offset(size.width - margin, margin), stroke)
    drawLine(accent, Offset(size.width - margin, margin), Offset(size.width - margin, margin + bracket), stroke)
    drawLine(accent, Offset(margin, size.height - margin), Offset(margin + bracket, size.height - margin), stroke)
    drawLine(accent, Offset(margin, size.height - margin - bracket), Offset(margin, size.height - margin), stroke)
    drawLine(accent, Offset(size.width - margin - bracket, size.height - margin), Offset(size.width - margin, size.height - margin), stroke)
    drawLine(accent, Offset(size.width - margin, size.height - margin - bracket), Offset(size.width - margin, size.height - margin), stroke)

    val center = Offset(size.width / 2f, size.height / 2f)
    drawCircle(FridayBlue.copy(alpha = 0.035f), size.minDimension * 0.29f, center, style = Stroke(0.8.dp.toPx()))
    drawCircle(FridayCyan.copy(alpha = 0.025f), size.minDimension * 0.34f, center, style = Stroke(0.7.dp.toPx()))
    drawLine(FridayCyan.copy(alpha = 0.035f), Offset(center.x, margin + bracket), Offset(center.x, size.height - margin - bracket), 0.6.dp.toPx())
}