package com.aditya.friday.ai

import com.aditya.friday.data.ConversationTurn
import java.net.URI
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.CancellationException
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class GroqAiClient(okHttpClient: OkHttpClient? = null) {
    private val client = okHttpClient ?: OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()

    private val api = Retrofit.Builder()
        .baseUrl("https://api.groq.com/")
        .client(client)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(GroqApi::class.java)

    suspend fun testConnection(endpoint: String, model: String, apiKey: String): AiCallResult = complete(
        endpoint = endpoint,
        model = model,
        apiKey = apiKey,
        turns = listOf(ConversationTurn("user", "Reply with a short greeting confirming the connection.")),
        assistantName = "FRIDAY",
        preferredName = "",
    )

    suspend fun chat(
        endpoint: String,
        model: String,
        apiKey: String,
        turns: List<ConversationTurn>,
        assistantName: String,
        preferredName: String,
    ): AiCallResult = complete(endpoint, model, apiKey, turns, assistantName, preferredName)

    private suspend fun complete(
        endpoint: String,
        model: String,
        apiKey: String,
        turns: List<ConversationTurn>,
        assistantName: String,
        preferredName: String,
    ): AiCallResult {
        val endpointFailure = validateEndpoint(endpoint)
        if (endpointFailure != null) return AiCallResult.Failure(endpointFailure)
        if (model.isBlank()) return AiCallResult.Failure("Enter a model name supported by your provider.")
        if (apiKey.isBlank()) return AiCallResult.Failure("Save an API key before connecting.")

        val instruction = """You are $assistantName, a private Android voice assistant. Address the user${
            preferredName.takeIf(String::isNotBlank)?.let { " as $it" } ?: " naturally"
        }. Understand Hindi, Hinglish, and English. Keep replies concise and practical.
Return one JSON object only, with this shape: {"type":"CHAT","response":"..."}.
For a supported local device request, use one of these type values and fields:
OPEN_APP {"app":"installed app name"}; OPEN_SETTINGS {"target":"GENERAL|WIFI|BLUETOOTH|DISPLAY"};
NAVIGATE {"target":"BACK|HOME|SCROLL_UP|SCROLL_DOWN"}; VOLUME {"direction":"UP|DOWN"};
SEARCH_WEB {"query":"..."}; TYPE_TEXT {"text":"..."}; CLEAR_TEXT {}; CLICK_ACCESSIBLE {"label":"visible button label"}; OPEN_WHATSAPP_CHAT {"recipient":"..."};
WHATSAPP_PREPARE_SEND {"recipient":"...","message":"..."}; LOCK_PHONE {}.
Never claim an action succeeded before the Android app confirms it. Message sends always require a separate user confirmation.
Never request or reveal passwords or API keys. Never produce executable code or unlisted action types.""".trimIndent()
        val messages = buildList {
            add(ApiMessage("system", instruction))
            turns.takeLast(12).forEach { turn ->
                if (turn.role == "user" || turn.role == "assistant") add(ApiMessage(turn.role, turn.content))
            }
        }

        return try {
            val response = api.complete(
                endpoint = endpoint.trim(),
                authorization = "Bearer ${apiKey.trim()}",
                request = ChatCompletionRequest(model = model.trim(), messages = messages),
            )
            if (!response.isSuccessful) {
                val message = when (response.code()) {
                    401, 403 -> "Provider rejected the API key (${response.code()}). Check the key and provider account."
                    404 -> "Endpoint or model was not found (${response.code()}). Check both values."
                    429 -> "Provider rate limit reached (${response.code()}). Free-tier limits may apply; try again later."
                    else -> "Provider request failed with HTTP ${response.code()}. Check endpoint, model, network, and provider limits."
                }
                AiCallResult.Failure(message)
            } else {
                val text = response.body()?.choices?.firstOrNull()?.message?.content?.trim().orEmpty()
                if (text.isBlank()) AiCallResult.Failure("The provider returned an empty response.")
                else AiCallResult.Success(text)
            }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (failure: UnknownHostException) {
            AiCallResult.Failure("No internet connection. Local commands remain available.")
        } catch (_: Exception) {
            AiCallResult.Failure("The AI request could not be completed. Check the endpoint and network connection.")
        }
    }

    private fun validateEndpoint(endpoint: String): String? {
        val uri = runCatching { URI(endpoint.trim()) }.getOrNull()
            ?: return "Enter a valid OpenAI-compatible chat-completions URL."
        val scheme = uri.scheme?.lowercase()
        val localHost = uri.host?.lowercase() in setOf("localhost", "127.0.0.1", "10.0.2.2", "::1")
        if (uri.userInfo != null || uri.fragment != null || uri.host.isNullOrBlank()) {
            return "Endpoint must be a complete URL without embedded credentials or a fragment."
        }
        if (scheme != "https" && !(scheme == "http" && localHost)) {
            return "Use HTTPS for remote providers. HTTP is allowed only for a local development server."
        }
        return null
    }
}