package com.aditya.friday

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aditya.friday.ui.FridayApp
import com.aditya.friday.ui.FridayViewModel
import com.aditya.friday.ui.FridayTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }
        setContent {
            FridayTheme {
                val assistantViewModel: FridayViewModel = viewModel()
                FridayApp(assistantViewModel)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        ViewModelProvider(this)[FridayViewModel::class.java].refreshStatuses()
    }
}