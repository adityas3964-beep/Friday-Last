package com.aditya.friday.ui

import android.app.Application
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.provider.Settings
import android.speech.SpeechRecognizer
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aditya.friday.admin.PhoneAdminReceiver
import com.aditya.friday.ai.AiCallResult
import com.aditya.friday.ai.AssistantEngine
import com.aditya.friday.automation.FridayAccessibilityService
import com.aditya.friday.data.CommandLogEntry
import com.aditya.friday.data.FridaySettings
import com.aditya.friday.data.SettingsRepository
import com.aditya.friday.security.ApiKeyVault
import com.aditya.friday.voice.SpeechController
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

data class FridayUiState(
    val settings: FridaySettings = FridaySettings(),
    val mode: String = "READY",
    val recognized: String = "",
    val response: String = "FRIDAY is ready. Start listening, use Push To Talk, or type a message.",
    val logs: List<CommandLogEntry> = emptyList(),
    val lastEngine: String = "NOT USED",
    val lastActionResult: String = "READY",
    val micGranted: Boolean = false,
    val recognitionAvailable: Boolean = false,
    val accessibilityEnabled: Boolean = false,
    val deviceAdminEnabled: Boolean = false,
    val internetAvailable: Boolean = false,
    val keySaved: Boolean = false,
    val connectionStatus: String = "NOT TESTED",
    val connectionMessage: String = "Connection has not been tested.",
    val testingConnection: Boolean = false,
    val apiKeyMessage: String = "",
)

class FridayViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = SettingsRepository(application)
    private val vault = ApiKeyVault(repository)
    private val engine = AssistantEngine(application, repository, vault)
    private val speech = SpeechController(
        context = application,
        onTranscript = { transcript -> handleInput(transcript) },
        onStatus = ::updateSpeechStatus,
        onSpeechComplete = ::speechCompleted,
    )
    private var commandJob: Job? = null

    var state = FridayUiState(
        settings = repository.loadSettings(),
        logs = repository.loadRecentLogs(),
        keySaved = runCatching { repository.hasApiKey() && vault.read() != null }.getOrDefault(false),
    )
        private set

    init {
        FridayAccessibilityService.onAutomationResult = { result, succeeded ->
            val label = if (succeeded) "ACTION SUCCESS" else "ACTION FAILED"
            state = state.copy(response = result, lastActionResult = label, mode = "READY")
            val log = CommandLogEntry(
                timestamp = System.currentTimeMillis(),
                recognized = "WhatsApp accessibility result",
                response = result,
                engine = "ANDROID ACCESSIBILITY",
                result = label,
            )
            repository.appendLog(log)
            state = state.copy(logs = repository.loadRecentLogs())
        }
        refreshStatuses()
    }

    fun refreshStatuses() {
        val app = getApplication<Application>()
        val micGranted = app.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED
        val admin = app.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val component = ComponentName(app, PhoneAdminReceiver::class.java)
        state = state.copy(
            micGranted = micGranted,
            recognitionAvailable = runCatching { SpeechRecognizer.isRecognitionAvailable(app) }.getOrDefault(false),
            accessibilityEnabled = isAccessibilityEnabled(app),
            deviceAdminEnabled = admin.isAdminActive(component),
            internetAvailable = hasValidatedInternet(app),
            keySaved = runCatching { repository.hasApiKey() && vault.read() != null }.getOrDefault(false),
        )
    }

    fun updateSettings(update: (FridaySettings) -> FridaySettings) {
        val settings = update(state.settings)
        repository.saveSettings(settings)
        state = state.copy(settings = settings)
    }

    fun startListening() {
        if (!state.micGranted) {
            state = state.copy(mode = "NEEDS MICROPHONE PERMISSION", lastActionResult = "NEEDS PERMISSION")
            return
        }
        speech.startListening(state.settings, automatic = state.settings.automaticRecognition)
    }

    fun microphonePermissionDenied() {
        state = state.copy(
            mode = "NEEDS MICROPHONE PERMISSION",
            lastActionResult = "NEEDS PERMISSION",
            response = "Microphone access was not granted. Voice controls remain off; you can still type commands below.",
        )
    }

    fun startPushToTalk() {
        if (!state.micGranted) {
            state = state.copy(mode = "NEEDS MICROPHONE PERMISSION", lastActionResult = "NEEDS PERMISSION")
            return
        }
        speech.startPushToTalk(state.settings)
    }

    fun releasePushToTalk() = speech.releasePushToTalk()

    fun stop() {
        commandJob?.cancel()
        commandJob = null
        speech.stop()
        state = state.copy(mode = "READY", lastActionResult = "STOPPED")
    }

    fun submitText(text: String) = handleInput(text)

    fun saveApiKey(value: String) {
        val saved = runCatching { vault.save(value); true }.getOrElse { false }
        state = state.copy(
            keySaved = saved || runCatching { repository.hasApiKey() && vault.read() != null }.getOrDefault(false),
            apiKeyMessage = if (saved) "API key encrypted and saved on this device." else "Could not save the key securely. Re-enter it and try again.",
        )
    }

    fun removeApiKey() {
        vault.clear()
        state = state.copy(keySaved = false, apiKeyMessage = "Saved API key removed from this device.")
    }

    fun testConnection() {
        if (state.testingConnection) return
        state = state.copy(testingConnection = true, connectionStatus = "TESTING", connectionMessage = "Sending a real test request to the configured endpoint.")
        viewModelScope.launch {
            val result = engine.testConnection(state.settings)
            val status = when (result) {
                is AiCallResult.Success -> "CONNECTED"
                is AiCallResult.Failure -> "FAILED"
            }
            val message = when (result) {
                is AiCallResult.Success -> "Provider responded: ${result.text.take(240)}"
                is AiCallResult.Failure -> result.message
            }
            state = state.copy(
                testingConnection = false,
                connectionStatus = status,
                connectionMessage = message,
                internetAvailable = hasValidatedInternet(getApplication()),
            )
        }
    }

    fun openAccessibilitySetup() {
        launchSettings(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    fun configureDeviceAdmin() {
        val app = getApplication<Application>()
        val component = ComponentName(app, PhoneAdminReceiver::class.java)
        val manager = app.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val intent = if (manager.isAdminActive(component)) {
            Intent(Settings.ACTION_SECURITY_SETTINGS)
        } else {
            Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, component)
                putExtra(
                    DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                    "FRIDAY uses only the force-lock policy, and only when you explicitly ask to lock the screen. It does not wipe data or change passwords.",
                )
            }
        }
        launchSettings(intent)
    }

    fun openProviderWebsite() {
        launchSettings(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://console.groq.com/keys")))
    }

    private fun handleInput(text: String) {
        val input = text.trim()
        if (input.isBlank()) return
        state = state.copy(recognized = input, mode = "THINKING", lastActionResult = "RUNNING")
        commandJob?.cancel()
        commandJob = viewModelScope.launch {
            val outcome = try {
                engine.handle(input, state.settings)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                com.aditya.friday.ai.AssistantOutcome(
                    response = "FRIDAY could not complete that action. Check the relevant permission or setting and try again.",
                    engine = "LOCAL COMMAND",
                    resultLabel = "ACTION FAILED",
                )
            }
            val entry = CommandLogEntry(
                timestamp = System.currentTimeMillis(),
                recognized = input,
                response = outcome.response,
                engine = outcome.engine,
                result = outcome.resultLabel,
            )
            repository.appendLog(entry)
            state = state.copy(
                response = outcome.response,
                mode = if (outcome.resultLabel == "NEEDS CONFIRMATION") "NEEDS CONFIRMATION" else "READY",
                lastEngine = outcome.engine,
                lastActionResult = outcome.resultLabel,
                logs = repository.loadRecentLogs(),
            )
            speech.speak(outcome.response, state.settings)
        }
    }

    private fun updateSpeechStatus(status: String) {
        val mode = when {
            status == "SPEAKING" -> "SPEAKING"
            status == "LISTENING" -> "LISTENING"
            status == "THINKING" -> "THINKING"
            status == "IDLE" -> "READY"
            status.startsWith("NEEDS") || status.contains("UNAVAILABLE") || status.contains("ERROR") -> status
            status == "NO SPEECH RECOGNIZED" -> "READY"
            status == "RECOGNIZER BUSY" -> "READY"
            else -> state.mode
        }
        state = state.copy(mode = mode)
        if (status.startsWith("NEEDS MICROPHONE")) {
            state = state.copy(lastActionResult = "NEEDS PERMISSION")
        }
    }

    private fun speechCompleted() {
        if (state.mode == "SPEAKING") state = state.copy(mode = "READY")
    }

    private fun isAccessibilityEnabled(context: Context): Boolean {
        val services = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,
        ) ?: return false
        val component = ComponentName(context, FridayAccessibilityService::class.java).flattenToString()
        return services.split(':').any { it.equals(component, ignoreCase = true) }
    }

    private fun hasValidatedInternet(context: Context): Boolean {
        val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = manager.activeNetwork ?: return false
        val capabilities = manager.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    private fun launchSettings(intent: Intent) {
        runCatching {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            getApplication<Application>().startActivity(intent)
        }.onFailure {
            state = state.copy(lastActionResult = "ACTION FAILED", response = "Android could not open that settings screen.")
        }
    }

    override fun onCleared() {
        FridayAccessibilityService.onAutomationResult = null
        speech.dispose()
        super.onCleared()
    }
}