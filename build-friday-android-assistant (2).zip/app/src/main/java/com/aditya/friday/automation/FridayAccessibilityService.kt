package com.aditya.friday.automation

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.aditya.friday.commands.AccessibilityScroll
import java.util.Locale

class FridayAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var automation: Automation? = null
    private var attempt = 0

    override fun onServiceConnected() {
        super.onServiceConnected()
        activeService = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (automation != null) scheduleStep(250)
    }

    override fun onInterrupt() {
        automation = null
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (activeService === this) activeService = null
        super.onDestroy()
    }

    fun scroll(direction: AccessibilityScroll): Boolean {
        val root = rootInActiveWindow ?: return false
        val action = if (direction == AccessibilityScroll.DOWN) {
            AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        } else {
            AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        }
        if (performScrollable(root, action)) return true
        val metrics = resources.displayMetrics
        val centerX = metrics.widthPixels / 2f
        val fromY = if (direction == AccessibilityScroll.DOWN) metrics.heightPixels * 0.72f else metrics.heightPixels * 0.35f
        val toY = if (direction == AccessibilityScroll.DOWN) metrics.heightPixels * 0.35f else metrics.heightPixels * 0.72f
        val path = Path().apply { moveTo(centerX, fromY); lineTo(centerX, toY) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 350))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    fun typeIntoFocusedField(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?.takeIf { it.isEditable }
            ?: collect(root).firstOrNull { it.isEditable }
            ?: return false
        return setText(node, text.take(1000))
    }

    fun clearFocusedField(): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?.takeIf { it.isEditable }
            ?: collect(root).firstOrNull { it.isEditable }
            ?: return false
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        return node.performAction(
            AccessibilityNodeInfo.ACTION_SET_TEXT,
            Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "") },
        )
    }

    fun clickAccessibleButton(label: String): Boolean {
        if (label.isBlank()) return false
        val root = rootInActiveWindow ?: return false
        val matches = collect(root).filter { node ->
            val visibleLabel = "${node.text.safe()} ${node.contentDescription.safe()}".trim()
            node.isClickable && visibleLabel.contains(label, ignoreCase = true)
        }
        return matches.singleOrNull()?.let(::clickNode) == true
    }

    fun requestContactSearch(recipient: String): Boolean {
        if (recipient.isBlank()) return false
        verifiedRecipient = null
        automation = Automation.ContactSearch(recipient.trim().take(80))
        attempt = 0
        scheduleStep(850)
        return true
    }

    fun requestConfirmedMessage(recipient: String, message: String): Boolean {
        if (message.isBlank() || activePackage() !in WHATSAPP_PACKAGES) return false
        if (!verifiedRecipient.equals(recipient, ignoreCase = true)) return false
        automation = Automation.SendMessage(recipient.trim(), message.take(1000))
        attempt = 0
        scheduleStep(350)
        return true
    }

    private fun scheduleStep(delay: Long) {
        handler.removeCallbacks(step)
        handler.postDelayed(step, delay)
    }

    private val step = Runnable {
        val root = rootInActiveWindow
        if (root == null || activePackage() !in WHATSAPP_PACKAGES) {
            if (++attempt > 8) failAutomation("WhatsApp is not showing an accessible screen. Nothing was sent.")
            else scheduleStep(500)
            return@Runnable
        }
        when (val task = automation) {
            is Automation.ContactSearch -> driveContactSearch(root, task)
            is Automation.SendMessage -> driveSend(root, task)
            null -> Unit
        }
    }

    private fun driveContactSearch(root: AccessibilityNodeInfo, task: Automation.ContactSearch) {
        val nodes = collect(root)
        val searchField = nodes.firstOrNull { node ->
            node.isEditable && !node.hintText.safe().contains("message") && !node.contentDescription.safe().contains("message")
        }
        if (searchField != null && task.stage < 2) {
            val entered = setText(searchField, task.recipient)
            if (entered) {
                task.stage = 2
                attempt = 0
                scheduleStep(900)
            } else retryOrFail("I could not enter the contact name in WhatsApp search.")
            return
        }

        if (task.stage == 0) {
            val searchButton = nodes.firstOrNull { node ->
                val label = "${node.text.safe()} ${node.contentDescription.safe()}".lowercase(Locale.ROOT)
                label.contains("search") && node.isClickable
            }
            if (searchButton?.let(::clickNode) == true) {
                task.stage = 1
                attempt = 0
                scheduleStep(600)
            } else retryOrFail("WhatsApp search is not accessible on this screen. Search for ${task.recipient} manually.")
            return
        }

        if (task.stage == 1) {
            if (++attempt > 8) failAutomation("WhatsApp search field did not appear. Search for ${task.recipient} manually.")
            else scheduleStep(350)
            return
        }

        if (task.stage == 2) {
            val target = task.recipient.lowercase(Locale.ROOT)
            val matches = nodes.filter { node ->
                !node.isEditable && node.text.safe().trim().equals(task.recipient, ignoreCase = true)
            }
            if (matches.size == 1 && clickNode(matches.first())) {
                task.stage = 3
                attempt = 0
                scheduleStep(1100)
                return
            }
            val visibleSimilar = nodes.map { it.text.safe().trim() }
                .filter { it.isNotBlank() && it.lowercase(Locale.ROOT).contains(target) }
                .distinct()
            if (visibleSimilar.size > 1) {
                failAutomation("More than one contact matched ${task.recipient}. Choose the correct chat manually.")
            } else if (++attempt > 10) {
                failAutomation("No exact accessible contact match for ${task.recipient}. No message was sent.")
            } else scheduleStep(550)
            return
        }

        if (task.stage == 3) {
            val composer = findMessageComposer(nodes)
            if (composer != null && isRecipientVisible(nodes, task.recipient)) {
                verifiedRecipient = task.recipient
                automation = null
                onAutomationResult?.invoke(
                    "WhatsApp shows the ${task.recipient} conversation. Review the chat before asking FRIDAY to prepare a message.",
                    true,
                )
            } else if (++attempt > 8) {
                failAutomation("WhatsApp did not expose a verified message composer. The chat was not confirmed.")
            } else scheduleStep(500)
        }
    }

    private fun driveSend(root: AccessibilityNodeInfo, task: Automation.SendMessage) {
        val nodes = collect(root)
        when (task.stage) {
            0 -> {
                if (!verifiedRecipient.equals(task.recipient, ignoreCase = true)) {
                    failAutomation("The active WhatsApp chat no longer matches ${task.recipient}. Nothing was sent.")
                    return
                }
                if (!isRecipientVisible(nodes, task.recipient)) {
                    failAutomation("I could not verify ${task.recipient} as the current chat. Nothing was sent.")
                    return
                }
                val composer = findMessageComposer(nodes)
                if (composer == null) {
                    failAutomation("WhatsApp's message field was not found. Nothing was sent.")
                } else {
                    val previousCount = nodes.count { it.text.safe().trim() == task.message }
                    if (setText(composer, task.message)) {
                        task.visibleMessageCountBefore = previousCount
                        task.stage = 1
                        scheduleStep(450)
                    } else {
                        failAutomation("Android did not accept the message text. Nothing was sent.")
                    }
                }
            }
            1 -> {
                val send = nodes.firstOrNull { node ->
                    val label = "${node.text.safe()} ${node.contentDescription.safe()}".lowercase(Locale.ROOT)
                    node.isClickable && (label.contains("send") || label.contains("enviar"))
                }
                if (send?.let(::clickNode) == true) {
                    task.stage = 2
                    attempt = 0
                    scheduleStep(1400)
                } else if (++attempt > 6) {
                    failAutomation("WhatsApp's Send button was not accessible. The message remains unsent.")
                } else scheduleStep(350)
            }
            else -> {
                val visibleMessageCount = nodes.count { it.text.safe().trim() == task.message }
                val composer = findMessageComposer(nodes)
                val composerEmpty = composer?.text.safe().isBlank()
                if (visibleMessageCount > task.visibleMessageCountBefore && composerEmpty) {
                    automation = null
                    onAutomationResult?.invoke(
                        "The message is visible in the ${task.recipient} conversation. WhatsApp delivery and read status are not verified.",
                        true,
                    )
                } else if (++attempt > 5) {
                    failAutomation("I could not verify the message in WhatsApp. Check the conversation; delivery was not confirmed.")
                } else scheduleStep(600)
            }
        }
    }

    private fun findMessageComposer(nodes: List<AccessibilityNodeInfo>): AccessibilityNodeInfo? = nodes.firstOrNull { node ->
        if (!node.isEditable) return@firstOrNull false
        val hint = "${node.hintText.safe()} ${node.contentDescription.safe()}".lowercase(Locale.ROOT)
        hint.contains("message") && !hint.contains("search")
    } ?: nodes.firstOrNull { node ->
        node.isEditable && !node.hintText.safe().lowercase(Locale.ROOT).contains("search") &&
            !node.contentDescription.safe().lowercase(Locale.ROOT).contains("search") &&
            node.text.safe().length < 200
    }

    private fun isRecipientVisible(nodes: List<AccessibilityNodeInfo>, recipient: String): Boolean =
        nodes.any { node -> node.text.safe().trim().equals(recipient, ignoreCase = true) }

    private fun setText(node: AccessibilityNodeInfo, text: String): Boolean {
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun clickNode(node: AccessibilityNodeInfo): Boolean {
        var candidate: AccessibilityNodeInfo? = node
        repeat(6) {
            if (candidate == null) return false
            if (candidate?.isClickable == true) return candidate?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
            candidate = candidate?.parent
        }
        return false
    }

    private fun performScrollable(root: AccessibilityNodeInfo, action: Int): Boolean =
        collect(root).firstOrNull { it.isScrollable }?.performAction(action) == true

    private fun collect(root: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val result = mutableListOf<AccessibilityNodeInfo>()
        fun visit(node: AccessibilityNodeInfo) {
            result.add(node)
            for (index in 0 until node.childCount) node.getChild(index)?.let(::visit)
        }
        visit(root)
        return result
    }

    private fun activePackage(): String? = rootInActiveWindow?.packageName?.toString()

    private fun retryOrFail(message: String) {
        if (++attempt > 5) failAutomation(message) else scheduleStep(500)
    }

    private fun failAutomation(message: String) {
        automation = null
        onAutomationResult?.invoke(message, false)
    }

    private fun CharSequence?.safe(): String = this?.toString().orEmpty()

    private sealed interface Automation {
        data class ContactSearch(val recipient: String, var stage: Int = 0) : Automation
        data class SendMessage(
            val recipient: String,
            val message: String,
            var stage: Int = 0,
            var visibleMessageCountBefore: Int = 0,
        ) : Automation
    }

    companion object {
        private val WHATSAPP_PACKAGES = setOf("com.whatsapp", "com.whatsapp.w4b")

        @Volatile
        var activeService: FridayAccessibilityService? = null
            private set

        @Volatile
        var verifiedRecipient: String? = null
            private set

        @Volatile
        var onAutomationResult: ((String, Boolean) -> Unit)? = null
    }
}