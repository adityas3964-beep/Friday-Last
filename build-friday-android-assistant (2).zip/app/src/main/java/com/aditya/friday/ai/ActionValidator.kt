package com.aditya.friday.ai

import com.aditya.friday.commands.AssistantAction
import com.aditya.friday.commands.NavigationTarget
import com.aditya.friday.commands.SettingsTarget
import com.aditya.friday.data.WhatsAppDraft
import com.google.gson.JsonObject
import com.google.gson.JsonParser

data class ValidatedAiReply(val response: String, val action: AssistantAction? = null)

class ActionValidator {
    fun validate(content: String): ValidatedAiReply {
        val body = content.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val json = runCatching { JsonParser.parseString(body).takeIf { it.isJsonObject }?.asJsonObject }.getOrNull()
            ?: return ValidatedAiReply(content.trim())
        val response = json.safeString("response").orEmpty().trim().take(2000)
        val action = when (json.safeString("type").orEmpty().uppercase()) {
            "CHAT", "" -> null
            "OPEN_APP" -> json.safeString("app")?.let(AssistantAction::OpenApp)
            "OPEN_SETTINGS" -> json.safeString("target")?.let { target ->
                SettingsTarget.entries.firstOrNull { it.name == target.uppercase() }
                    ?.let(AssistantAction::OpenSettings)
            }
            "NAVIGATE" -> json.safeString("target")?.let { target ->
                NavigationTarget.entries.firstOrNull { it.name == target.uppercase() }
                    ?.let(AssistantAction::Navigate)
            }
            "VOLUME" -> when (json.safeString("direction").orEmpty().uppercase()) {
                "UP" -> AssistantAction.AdjustVolume(1)
                "DOWN" -> AssistantAction.AdjustVolume(-1)
                else -> null
            }
            "SEARCH_WEB" -> json.safeString("query")?.let(AssistantAction::SearchWeb)
            "TYPE_TEXT" -> json.safeString("text")?.let(AssistantAction::TypeText)
            "CLEAR_TEXT" -> AssistantAction.ClearText
            "CLICK_ACCESSIBLE" -> json.safeString("label")?.let(AssistantAction::ClickAccessibleButton)
            "OPEN_WHATSAPP_CHAT" -> json.safeString("recipient")?.let(AssistantAction::OpenWhatsAppChat)
            "WHATSAPP_PREPARE_SEND" -> {
                val recipient = json.safeString("recipient")
                val message = json.safeString("message")
                if (recipient == null || message == null) null
                else AssistantAction.PrepareWhatsAppMessage(WhatsAppDraft(recipient, message))
            }
            "LOCK_PHONE" -> AssistantAction.LockPhone
            else -> null
        }
        return ValidatedAiReply(
            response = response.ifBlank { "I understood the request but did not receive a response." },
            action = action,
        )
    }

    private fun JsonObject.safeString(field: String): String? {
        val value = get(field)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isString }?.asString ?: return null
        return value.trim().takeIf { it.isNotBlank() && it.length <= 500 }
    }
}