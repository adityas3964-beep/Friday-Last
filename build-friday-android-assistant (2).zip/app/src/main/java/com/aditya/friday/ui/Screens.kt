package com.aditya.friday.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aditya.friday.data.CommandLogEntry
import com.aditya.friday.data.FridaySettings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
    state: FridayUiState,
    onStartListening: () -> Unit,
    onStartPushToTalk: () -> Unit,
    onReleasePushToTalk: () -> Unit,
    onStop: () -> Unit,
    onSubmit: (String) -> Unit,
    onOpenAccessibility: () -> Unit,
) {
    var draft by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 20.dp),
        verticalArrangement = Arrangement.spacedBy(15.dp),
    ) {
        HomeHeader(state)
        Box(Modifier.fillMaxWidth().height(258.dp), contentAlignment = Alignment.Center) {
            CoreOrb(state.mode, Modifier.size(258.dp))
        }
        Text(
            state.mode.uppercase(),
            modifier = Modifier.fillMaxWidth(),
            color = when {
                state.mode == "SPEAKING" || state.mode == "LISTENING" -> FridayCyan
                state.mode.contains("PERMISSION") || state.mode.contains("ERROR") -> FridayAmber
                else -> FridayText
            },
            fontFamily = FontFamily.Monospace,
            fontSize = 14.sp,
            letterSpacing = 5.sp,
            textAlign = TextAlign.Center,
            fontWeight = FontWeight.Medium,
        )
        SignalWaveform(active = state.mode in setOf("LISTENING", "THINKING", "SPEAKING"), Modifier.fillMaxWidth().height(56.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HudButton("Start\nListening", onStartListening, Modifier.weight(1f), height = 58.dp, primary = true)
            PressHoldButton("Push To Talk", onStartPushToTalk, onReleasePushToTalk, Modifier.weight(1.08f))
            HudButton("Stop", onStop, Modifier.weight(0.66f), height = 58.dp, danger = true)
        }

        HudPanel("Assistant") {
            FieldCaption("Heard")
            Text(
                state.recognized.ifBlank { "No speech or text command received yet." },
                Modifier.fillMaxWidth().padding(top = 4.dp),
                color = FridayText,
                fontFamily = FontFamily.Monospace,
                fontSize = 15.sp,
                lineHeight = 21.sp,
            )
            Spacer(Modifier.height(14.dp))
            FieldCaption("Response  /  ${state.lastEngine}")
            Text(
                state.response,
                Modifier.fillMaxWidth().padding(top = 4.dp),
                color = FridayCyan,
                fontFamily = FontFamily.Monospace,
                fontSize = 14.sp,
                lineHeight = 20.sp,
            )
            Spacer(Modifier.height(15.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = draft,
                    onValueChange = { draft = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Type a command or question", color = FridayMuted.copy(alpha = 0.7f), fontSize = 12.sp) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = {
                        val text = draft.trim()
                        if (text.isNotBlank()) onSubmit(text)
                        draft = ""
                    }),
                    textStyle = androidx.compose.ui.text.TextStyle(color = FridayText, fontFamily = FontFamily.Monospace, fontSize = 13.sp),
                    shape = RoundedCornerShape(3.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = FridayCyan,
                        unfocusedBorderColor = FridayMuted.copy(alpha = 0.45f),
                        cursorColor = FridayCyan,
                        focusedContainerColor = FridayBackground,
                        unfocusedContainerColor = FridayBackground,
                    ),
                )
                HudButton(
                    "Send",
                    onClick = {
                        val text = draft.trim()
                        if (text.isNotBlank()) onSubmit(text)
                        draft = ""
                    },
                    Modifier.width(76.dp),
                    height = 55.dp,
                    primary = true,
                )
            }
        }

        HudPanel("Recent Commands") {
            if (state.logs.isEmpty()) {
                BodyCopy("Commands appear here after FRIDAY receives and processes them.")
            } else {
                state.logs.take(3).forEachIndexed { index, entry ->
                    if (index > 0) Spacer(Modifier.height(8.dp))
                    Text(
                        text = ">  ${entry.recognized}",
                        color = FridayText,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        lineHeight = 17.sp,
                    )
                    Text(
                        text = "   ${entry.result}  /  ${entry.engine}",
                        color = toneForResult(entry.result),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        letterSpacing = 0.6.sp,
                    )
                }
            }
        }

        HudPanel("Service Status") {
            StatusRow("Recognition mode", if (state.settings.automaticRecognition) "AUTO / ON DEMAND" else "MANUAL", StatusTone.CYAN)
            StatusRow("Last engine used", state.lastEngine, if (state.lastEngine == "ONLINE AI") StatusTone.CYAN else StatusTone.NEUTRAL)
            StatusRow("Wake word (${state.settings.wakeWord})", "NOT RUNNING", StatusTone.WARN)
            StatusRow("Microphone permission", if (state.micGranted) "GRANTED" else "NEEDS PERMISSION", if (state.micGranted) StatusTone.GOOD else StatusTone.WARN)
            StatusRow("Android speech service", if (state.recognitionAvailable) "AVAILABLE" else "UNAVAILABLE", if (state.recognitionAvailable) StatusTone.GOOD else StatusTone.WARN)
            StatusRow("Offline local commands", "READY", StatusTone.GOOD)
            StatusRow("Accessibility", if (state.accessibilityEnabled) "ENABLED" else "OFF", if (state.accessibilityEnabled) StatusTone.GOOD else StatusTone.WARN)
            StatusRow("Online AI", onlineLabel(state), onlineTone(state))
            StatusRow("Last action", state.lastActionResult, statusToneForResult(state.lastActionResult))
            if (!state.accessibilityEnabled) {
                Spacer(Modifier.height(8.dp))
                HudButton("Set Up Accessibility", onOpenAccessibility, Modifier.fillMaxWidth(), height = 46.dp)
            }
        }
        AboutFooter()
    }
}

@Composable
fun LogScreen(state: FridayUiState) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(15.dp),
    ) {
        ScreenHeader("Command Log", "RECENT ACTIONS AND REAL RESULTS")
        HudPanel("Stored On This Device  /  ${state.logs.size}") {
            BodyCopy("Logs contain transcripts, response summaries, engine labels, and action results. They stay in app storage and are not sent to FRIDAY's AI provider unless included in a conversation request.")
        }
        if (state.logs.isEmpty()) {
            HudPanel("No Commands Yet") {
                BodyCopy("Start a listening session or type a command on Home. Only received input is logged; FRIDAY does not create sample recognition results.", color = FridayText)
            }
        } else {
            HudPanel("Latest First") {
                state.logs.forEachIndexed { index, entry ->
                    if (index > 0) Spacer(Modifier.height(15.dp))
                    LogEntryView(entry)
                }
            }
        }
        AboutFooter()
    }
}

@Composable
fun ProfileScreen(settings: FridaySettings, onUpdate: ((FridaySettings) -> FridaySettings) -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(15.dp),
    ) {
        ScreenHeader("Profile", "PERSONALIZE YOUR ASSISTANT")
        HudPanel("Your Preferences") {
            FridayTextField(
                value = settings.preferredName,
                onValueChange = { value -> onUpdate { it.copy(preferredName = value.take(50)) } },
                label = "Preferred name",
                placeholder = "What should FRIDAY call you?",
            )
            Spacer(Modifier.height(12.dp))
            FridayTextField(
                value = settings.assistantName,
                onValueChange = { value -> onUpdate { it.copy(assistantName = value.take(40).ifBlank { "FRIDAY" }) } },
                label = "Assistant name",
                placeholder = "FRIDAY",
            )
            Spacer(Modifier.height(14.dp))
            SelectionField(
                label = "Language / recognition preference",
                value = if (settings.language == "en-IN") "English (India)" else "Hindi / Hinglish (India)",
                options = listOf("Hindi / Hinglish (India)", "English (India)"),
                onSelect = { label -> onUpdate { it.copy(language = if (label.startsWith("English")) "en-IN" else "hi-IN") } },
            )
            Spacer(Modifier.height(14.dp))
            SelectionField(
                label = "Voice preference",
                value = when (settings.voiceLocale) {
                    "hi-IN" -> "Hindi (if installed)"
                    "en-IN" -> "English (India, if installed)"
                    else -> "Automatic / system fallback"
                },
                options = listOf("Automatic / system fallback", "Hindi (if installed)", "English (India, if installed)"),
                onSelect = { value ->
                    val locale = when {
                        value.startsWith("Hindi") -> "hi-IN"
                        value.startsWith("English") -> "en-IN"
                        else -> "AUTO"
                    }
                    onUpdate { it.copy(voiceLocale = locale) }
                },
            )
            Spacer(Modifier.height(8.dp))
            BodyCopy("Speech output uses Android TextToSpeech. Available languages and voices depend on the speech packages installed on your phone; English/system voice is used if Hindi is unavailable.")
        }
        HudPanel("About FRIDAY") {
            Text("FRIDAY – Personal AI Assistant", color = FridayText, fontFamily = FontFamily.Monospace, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(7.dp))
            BodyCopy("Whole credit goes to Aditya.", color = FridayCyan)
            Spacer(Modifier.height(4.dp))
            BodyCopy("© 2026 Aditya. All rights reserved.")
            Spacer(Modifier.height(8.dp))
            BodyCopy("FRIDAY uses Android platform speech recognition, TextToSpeech, Accessibility, Retrofit, OkHttp, and Jetpack Compose. See the source project for dependency versions and licenses.")
        }
    }
}

@Composable
fun SettingsScreen(
    state: FridayUiState,
    onUpdate: ((FridaySettings) -> FridaySettings) -> Unit,
    onSaveKey: (String) -> Unit,
    onRemoveKey: () -> Unit,
    onTestConnection: () -> Unit,
    onOpenAccessibility: () -> Unit,
    onConfigureDeviceAdmin: () -> Unit,
    onOpenProviderWebsite: () -> Unit,
) {
    var apiKey by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(15.dp),
    ) {
        ScreenHeader("Settings", "LOCAL CONTROL, NETWORK, AND PRIVACY")

        HudPanel("Device Admin  /  Phone Lock") {
            StatusRow("Status", if (state.deviceAdminEnabled) "ACTIVE" else "OFF", if (state.deviceAdminEnabled) StatusTone.GOOD else StatusTone.WARN)
            Spacer(Modifier.height(4.dp))
            BodyCopy("Only Android's force-lock policy is requested. FRIDAY cannot wipe data or change your password. Permission is activated manually on the system screen.", color = FridayText)
            Spacer(Modifier.height(12.dp))
            HudButton(
                if (state.deviceAdminEnabled) "Open Deactivation Settings" else "Activate Device Admin",
                onConfigureDeviceAdmin,
                Modifier.fillMaxWidth(),
                height = 52.dp,
                primary = !state.deviceAdminEnabled,
            )
        }

        HudPanel("Accessibility Automation") {
            StatusRow("Status", if (state.accessibilityEnabled) "ENABLED" else "NEEDS PERMISSION", if (state.accessibilityEnabled) StatusTone.GOOD else StatusTone.WARN)
            Spacer(Modifier.height(5.dp))
            BodyCopy("Used only after you ask FRIDAY to navigate, fill a supported field, or assist with WhatsApp. Android shows its persistent accessibility indicator. Message sending requires a separate confirmation; delivery is never claimed.", color = FridayText)
            Spacer(Modifier.height(12.dp))
            HudButton("Open Accessibility Settings", onOpenAccessibility, Modifier.fillMaxWidth(), height = 50.dp)
        }

        HudPanel("AI Provider  /  Optional") {
            PreferenceSwitch(
                title = "Enable Online AI",
                subtitle = "Cloud conversations send your prompts to the endpoint below. Local commands work when this is off.",
                checked = state.settings.onlineAiEnabled,
                onCheckedChange = { enabled -> onUpdate { it.copy(onlineAiEnabled = enabled) } },
            )
            Spacer(Modifier.height(8.dp))
            SelectionField(
                label = "AI provider",
                value = state.settings.provider,
                options = listOf("Groq", "Custom OpenAI-compatible"),
                onSelect = { provider ->
                    onUpdate { current ->
                        current.copy(
                            provider = provider,
                            endpoint = if (provider == "Groq") "https://api.groq.com/openai/v1/chat/completions" else current.endpoint,
                        )
                    }
                },
            )
            Spacer(Modifier.height(12.dp))
            FridayTextField(
                value = state.settings.endpoint,
                onValueChange = { value -> onUpdate { it.copy(endpoint = value.take(500)) } },
                label = "API endpoint",
                placeholder = "https://api.groq.com/openai/v1/chat/completions",
                keyboardType = KeyboardType.Uri,
            )
            Spacer(Modifier.height(10.dp))
            FridayTextField(
                value = state.settings.modelName,
                onValueChange = { value -> onUpdate { it.copy(modelName = value.take(120)) } },
                label = "Model name",
                placeholder = "Enter a model currently supported by your provider",
            )
            Spacer(Modifier.height(10.dp))
            FridayTextField(
                value = apiKey,
                onValueChange = { apiKey = it.take(300) },
                label = "API key  /  ${if (state.keySaved) "saved securely" else "not saved"}",
                placeholder = if (state.keySaved) "Enter a new key to replace the saved key" else "Paste your provider API key",
                password = true,
                keyboardType = KeyboardType.Password,
            )
            Spacer(Modifier.height(4.dp))
            BodyCopy("Keys are encrypted with an Android Keystore AES/GCM key and are never written to logs. A provider key is required for cloud AI; free-tier availability and rate limits depend on the provider.")
            if (state.apiKeyMessage.isNotBlank()) {
                Spacer(Modifier.height(7.dp))
                BodyCopy(state.apiKeyMessage, color = if (state.keySaved) FridayGreen else FridayAmber)
            }
            Spacer(Modifier.height(11.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HudButton(
                    "Save Key",
                    onClick = { if (apiKey.isNotBlank()) onSaveKey(apiKey); apiKey = "" },
                    Modifier.weight(1f),
                    height = 52.dp,
                    primary = true,
                )
                HudButton(
                    if (state.testingConnection) "Testing" else "Test Connection",
                    onClick = onTestConnection,
                    Modifier.weight(1f),
                    height = 52.dp,
                    enabled = !state.testingConnection,
                )
            }
            if (state.keySaved) {
                Spacer(Modifier.height(8.dp))
                HudButton("Remove Saved Key", onRemoveKey, Modifier.fillMaxWidth(), height = 43.dp, danger = true)
            }
            Spacer(Modifier.height(14.dp))
            StatusRow("Connection", state.connectionStatus, when (state.connectionStatus) {
                "CONNECTED" -> StatusTone.GOOD
                "FAILED" -> StatusTone.BAD
                "TESTING" -> StatusTone.CYAN
                else -> StatusTone.NEUTRAL
            })
            BodyCopy(state.connectionMessage, Modifier.padding(top = 3.dp), color = FridayText)
            if (state.settings.provider == "Groq") {
                Spacer(Modifier.height(8.dp))
                HudButton("Get a Groq API Key", onOpenProviderWebsite, Modifier.fillMaxWidth(), height = 44.dp)
            }
        }

        HudPanel("Recognition And Wake Word") {
            PreferenceSwitch(
                title = "Automatic recognition",
                subtitle = "After you tap Start Listening, the Android speech service may restart between utterances. Stop ends the session.",
                checked = state.settings.automaticRecognition,
                onCheckedChange = { enabled -> onUpdate { it.copy(automaticRecognition = enabled) } },
            )
            Spacer(Modifier.height(9.dp))
            FridayTextField(
                value = state.settings.wakeWord,
                onValueChange = { value -> onUpdate { it.copy(wakeWord = value.take(32).ifBlank { "FRIDAY" }) } },
                label = "Wake word preference",
                placeholder = "FRIDAY",
            )
            Spacer(Modifier.height(7.dp))
            StatusRow("Local wake-word engine", "NOT RUNNING", StatusTone.WARN)
            BodyCopy("FRIDAY does not include an always-on wake-word model. This setting does not keep the microphone open. Use Start Listening or press and hold Push To Talk; Android's microphone indicator remains visible during recognition.")
        }

        HudPanel("Troubleshooting") {
            Bullet("If the microphone does not start, grant Microphone permission in Android App info and install/enable a speech recognition service.")
            Bullet("Offline recognition is available only when the installed Android speech service has downloaded an offline language pack; the app reports the platform engine, not a guarantee of offline results.")
            Bullet("If an app cannot open, install it or use its launcher name. App visibility and OEM restrictions vary.")
            Bullet("Accessibility actions depend on visible labels and app versions. If FRIDAY cannot verify a WhatsApp chat or send result, continue manually in WhatsApp.")
            Bullet("Provider keys, model names, network access, free-tier limits, and rate limits are controlled by your selected AI provider.")
        }
        AboutFooter()
    }
}

@Composable
private fun HomeHeader(state: FridayUiState) {
    Row(
        Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Column {
            Text("FRIDAY", color = FridayCyan, fontFamily = FontFamily.Monospace, fontSize = 22.sp, letterSpacing = 4.sp, fontWeight = FontWeight.Bold)
            Text("PERSONAL AI ASSISTANT", color = FridayMuted, fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 1.7.sp)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(if (state.settings.onlineAiEnabled) "ONLINE AI" else "LOCAL MODE", color = FridayCyan, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.2.sp)
            Text(if (state.internetAvailable) "NETWORK AVAILABLE" else "NETWORK OFFLINE", color = FridayMuted, fontFamily = FontFamily.Monospace, fontSize = 8.sp, letterSpacing = 0.7.sp)
        }
    }
}

@Composable
private fun ScreenHeader(title: String, eyebrow: String) {
    Column(Modifier.fillMaxWidth().padding(top = 19.dp, bottom = 2.dp)) {
        Text(title.uppercase(), color = FridayText, fontFamily = FontFamily.Monospace, fontSize = 22.sp, letterSpacing = 2.2.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        Text(eyebrow, color = FridayMuted, fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 1.2.sp)
    }
}

@Composable
private fun SelectionField(label: String, value: String, options: List<String>, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        Column {
            FieldCaption(label)
            Spacer(Modifier.height(5.dp))
            Box(
                Modifier.fillMaxWidth()
                    .clip(RoundedCornerShape(3.dp))
                    .background(FridayBackground)
                    .border(1.dp, FridayCyan.copy(alpha = 0.36f), RoundedCornerShape(3.dp))
                    .clickable { expanded = true }
                    .semantics { role = Role.Button }
                    .padding(horizontal = 12.dp, vertical = 14.dp),
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(value, Modifier.weight(1f), color = FridayText, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
                    Text("⌄", color = FridayCyan, fontSize = 16.sp)
                }
            }
        }
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.background(FridaySurfaceRaised),
        ) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option, color = FridayText, fontFamily = FontFamily.Monospace, fontSize = 12.sp) },
                    onClick = { expanded = false; onSelect(option) },
                )
            }
        }
    }
}

@Composable
private fun LogEntryView(entry: CommandLogEntry) {
    val date = remember(entry.timestamp) {
        SimpleDateFormat("dd MMM  HH:mm", Locale.getDefault()).format(Date(entry.timestamp))
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        FieldCaption(date)
        Text(entry.result.uppercase(), color = toneForResult(entry.result), fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 0.7.sp)
    }
    Text("> ${entry.recognized}", Modifier.padding(top = 5.dp), color = FridayText, fontFamily = FontFamily.Monospace, fontSize = 12.sp, lineHeight = 17.sp)
    Text(entry.response, Modifier.padding(top = 4.dp), color = FridayCyan, fontFamily = FontFamily.Monospace, fontSize = 11.sp, lineHeight = 16.sp)
    Text("ENGINE: ${entry.engine}", Modifier.padding(top = 4.dp), color = FridayMuted, fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 0.6.sp)
}

@Composable
private fun Bullet(text: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.Top) {
        Text("•", color = FridayCyan, fontFamily = FontFamily.Monospace, fontSize = 14.sp)
        Text(text, Modifier.padding(start = 8.dp), color = FridayText, fontFamily = FontFamily.Monospace, fontSize = 11.sp, lineHeight = 16.sp)
    }
}

@Composable
private fun AboutFooter() {
    Column(Modifier.fillMaxWidth().padding(top = 5.dp, bottom = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("FRIDAY  /  PERSONAL AI ASSISTANT", color = FridayMuted, fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 1.0.sp)
        Spacer(Modifier.height(4.dp))
        Text("Whole credit goes to Aditya.  ·  © 2026 Aditya.", color = FridayMuted.copy(alpha = 0.74f), fontFamily = FontFamily.Monospace, fontSize = 8.sp)
    }
}

private fun onlineLabel(state: FridayUiState): String = when {
    !state.settings.onlineAiEnabled -> "OFF"
    !state.internetAvailable -> "NO INTERNET"
    state.connectionStatus == "CONNECTED" -> "CONNECTED"
    state.connectionStatus == "FAILED" -> "TEST FAILED"
    else -> "NOT TESTED"
}

private fun onlineTone(state: FridayUiState): StatusTone = when (onlineLabel(state)) {
    "CONNECTED" -> StatusTone.GOOD
    "NO INTERNET", "TEST FAILED" -> StatusTone.WARN
    else -> StatusTone.NEUTRAL
}

private fun toneForResult(value: String): Color = when {
    value.contains("SUCCESS") || value.contains("CANCELLED") || value.contains("CONNECTED") -> FridayGreen
    value.contains("FAILED") -> FridayRed
    value.contains("PERMISSION") || value.contains("CONFIRMATION") || value.contains("MANUAL") || value.contains("VERIFY") -> FridayAmber
    else -> FridayMuted
}

private fun statusToneForResult(value: String): StatusTone = when {
    value.contains("SUCCESS") || value.contains("CANCELLED") -> StatusTone.GOOD
    value.contains("FAILED") -> StatusTone.BAD
    value.contains("PERMISSION") || value.contains("CONFIRMATION") || value.contains("MANUAL") || value.contains("VERIFY") -> StatusTone.WARN
    else -> StatusTone.NEUTRAL
}