package com.aditya.friday.commands

import com.aditya.friday.data.WhatsAppDraft

sealed interface AssistantAction {
    data class OpenApp(val name: String) : AssistantAction
    data class OpenSettings(val target: SettingsTarget) : AssistantAction
    data class Navigate(val target: NavigationTarget) : AssistantAction
    data class AdjustVolume(val direction: Int) : AssistantAction
    data class SearchWeb(val query: String) : AssistantAction
    data class TypeText(val text: String) : AssistantAction
    data object ClearText : AssistantAction
    data class ClickAccessibleButton(val label: String) : AssistantAction
    data class OpenWhatsAppChat(val recipient: String) : AssistantAction
    data class PrepareWhatsAppMessage(val draft: WhatsAppDraft) : AssistantAction
    data class ConfirmWhatsAppMessage(val approved: Boolean) : AssistantAction
    data class Clarify(val question: String) : AssistantAction
    data object LockPhone : AssistantAction
}

enum class SettingsTarget { GENERAL, WIFI, BLUETOOTH, DISPLAY }
enum class NavigationTarget { BACK, HOME, SCROLL_UP, SCROLL_DOWN }