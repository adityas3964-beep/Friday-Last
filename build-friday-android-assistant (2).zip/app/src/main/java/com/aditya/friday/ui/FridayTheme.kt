package com.aditya.friday.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val FridayBackground = Color(0xFF080D15)
val FridaySurface = Color(0xFF0D1621)
val FridaySurfaceRaised = Color(0xFF111E2B)
val FridayCyan = Color(0xFF00DDF5)
val FridayBlue = Color(0xFF2587FF)
val FridayText = Color(0xFFC3ECF8)
val FridayMuted = Color(0xFF7892A7)
val FridayGreen = Color(0xFF00E5A0)
val FridayAmber = Color(0xFFFFB01F)
val FridayRed = Color(0xFFFF4566)

@Composable
fun FridayTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = FridayCyan,
            secondary = FridayBlue,
            background = FridayBackground,
            surface = FridaySurface,
            onPrimary = FridayBackground,
            onBackground = FridayText,
            onSurface = FridayText,
            error = FridayRed,
        ),
        content = content,
    )
}