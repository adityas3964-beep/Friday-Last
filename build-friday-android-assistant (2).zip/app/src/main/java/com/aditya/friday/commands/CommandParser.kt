package com.aditya.friday.commands

import com.aditya.friday.data.WhatsAppDraft
import java.util.Locale

object SpeechTextNormalizer {
    fun normalize(input: String): String {
        var value = input.trim().replace(Regex("\\s+"), " ")
        val corrections = listOf(
            Regex("(?i)\\b(?:watsapp|vatsapp|vatsap|what'?s\\s*app|whats\\s+app)\\b") to "WhatsApp",
            Regex("(?i)\\b(?:you\\s*tube|youtub)\\b") to "YouTube",
            Regex("(?i)\\bchorme\\b") to "Chrome",
            Regex("(?i)\\bblue\\s+tooth\\b") to "Bluetooth",
        )
        corrections.forEach { (pattern, replacement) -> value = pattern.replace(value, replacement) }
        return value.replace(Regex("(?i)^friday[,:]?\\s*"), "").trim()
    }
}

class CommandParser(private val context: ConversationContextManager) {
    fun parse(input: String): AssistantAction? {
        val text = SpeechTextNormalizer.normalize(input)
        val folded = text.lowercase(Locale.ROOT)
        if (text.isBlank()) return null

        if (context.pendingDraft != null) {
            if (folded.matches(Regex("(?:haan|han|yes|yep|confirm|confirmed|bilkul|bhej do|send it)[.! ]*"))) {
                return AssistantAction.ConfirmWhatsAppMessage(approved = true)
            }
            if (folded.matches(Regex("(?:nahi|nahin|no|cancel|mat bhejo|don't send)[.! ]*"))) {
                return AssistantAction.ConfirmWhatsAppMessage(approved = false)
            }
        }

        parseWhatsAppChat(text)?.let { return it }
        parseWhatsAppMessage(text)?.let { return it }
        parseTextEntry(text)?.let { return it }
        parseButtonClick(text)?.let { return it }

        if (containsAny(folded, "clear text", "text clear", "field clear", "text saaf", "text hatao", "delete text")) {
            return AssistantAction.ClearText
        }

        if (containsAny(folded, "back jao", "go back", "pichhe jao", "wapas jao", "back")) {
            return AssistantAction.Navigate(NavigationTarget.BACK)
        }
        if (containsAny(folded, "home screen", "home par jao", "home jao", "go home", "ghar screen", "home screen par")) {
            return AssistantAction.Navigate(NavigationTarget.HOME)
        }
        if (containsAny(folded, "neeche scroll", "scroll down", "neeche jao", "page down")) {
            return AssistantAction.Navigate(NavigationTarget.SCROLL_DOWN)
        }
        if (containsAny(folded, "upar scroll", "scroll up", "upar jao", "page up")) {
            return AssistantAction.Navigate(NavigationTarget.SCROLL_UP)
        }

        if (containsAny(folded, "volume kam", "awaaz kam", "sound kam", "volume down", "volume low", "volume ghata")) {
            return AssistantAction.AdjustVolume(-1)
        }
        if (containsAny(folded, "volume badha", "volume zyada", "awaaz badha", "volume up", "volume high")) {
            return AssistantAction.AdjustVolume(1)
        }

        parseSettings(folded)?.let { return it }

        if (containsAny(folded, "phone lock", "phone lock karo", "lock phone", "screen lock karo", "phone ko lock")) {
            return AssistantAction.LockPhone
        }

        parseAppLaunch(text, folded)?.let { return it }
        parseSearch(text)?.let { return it }
        return null
    }

    private fun parseWhatsAppChat(text: String): AssistantAction.OpenWhatsAppChat? {
        val patterns = listOf(
            Regex("(?i)^(?:whatsapp\\s+(?:mein|me|par)\\s+)?(.+?)\\s+(?:ki|ka|ke)\\s+(?:chat|chats|conversation)\\s+(?:khol(?:o)?|open|dikhao)$"),
            Regex("(?i)^(?:whatsapp\\s+)?(?:open|khol(?:o)?)\\s+(?:the\\s+)?chat\\s+(?:with|of)\\s+(.+)$"),
        )
        val match = patterns.firstNotNullOfOrNull { it.find(text.trim()) } ?: return null
        val recipient = match.groupValues[1].trim().trimEnd('.', '?', '!')
        return recipient.takeIf { it.isNotBlank() }?.let(AssistantAction::OpenWhatsAppChat)
    }

    private fun parseWhatsAppMessage(text: String): AssistantAction? {
        val sendVerb = Regex("(?i)\\b(?:bhejo|bhej do|bhej dena|send(?: kar do| karo| it)?|message kar do)\\b")
        if (!sendVerb.containsMatchIn(text)) return null
        var body = sendVerb.replace(text, " ").trim().trimEnd('.', '?', '!')
        body = Regex("(?i)^.*?\\bwhatsapp\\s+(?:mein|me|par)\\s+").replace(body, "")
        body = Regex("(?i)^(?:please\\s+)?(?:message|msg)\\s+").replace(body, "")

        var recipient: String? = null
        val pronoun = Regex("(?i)^(?:usko|use|unko|unhe|unhein|them|him|her)\\s+")
        if (pronoun.containsMatchIn(body)) {
            body = pronoun.replaceFirst(body, "")
            body = Regex("(?i)\\s+(?:message|msg)$").replace(body, "")
            recipient = context.selectedRecipient
        } else {
            val explicit = Regex("(?i)^(.+?)\\s+ko\\s+(.+)$").find(body)
            if (explicit != null) {
                recipient = explicit.groupValues[1].trim()
                body = Regex("(?i)\\s+(?:message|msg)$").replace(explicit.groupValues[2].trim(), "")
            } else {
                val english = Regex("(?i)^send\\s+(.+?)\\s+to\\s+(.+)$").find(text.trim())
                if (english != null) {
                    body = english.groupValues[1].trim()
                    recipient = english.groupValues[2].trim()
                } else {
                    recipient = context.selectedRecipient
                    body = Regex("(?i)\\s+(?:message|msg)$").replace(body, "")
                }
            }
        }

        body = body.trim().trim('"', '\'', '`')
        if (body.lowercase(Locale.ROOT) in setOf("same", "same message", "wahi", "wahi message", "it", "that")) {
            body = context.previousMessage.orEmpty()
            if (body.isBlank()) return AssistantAction.Clarify("Kaunsa message bhejna hai? Message text dobara bol dein.")
        }
        val destination = recipient?.trim()?.takeIf(String::isNotBlank)
        if (destination == null) {
            return AssistantAction.Clarify("Kis contact ko message bhejna hai? Pehle WhatsApp chat khol dein.")
        }
        if (body.isBlank()) return null
        return AssistantAction.PrepareWhatsAppMessage(WhatsAppDraft(destination, body))
    }

    private fun parseTextEntry(text: String): AssistantAction.TypeText? {
        val match = Regex("(?i)^(?:search box|text field|box)\\s+(?:mein|me)\\s+(.+?)\\s+(?:likho|type karo|type|enter karo)$")
            .find(text.trim()) ?: return null
        return AssistantAction.TypeText(match.groupValues[1].trim().trim('"', '\'', '`'))
    }

    private fun parseButtonClick(text: String): AssistantAction.ClickAccessibleButton? {
        val patterns = listOf(
            Regex("(?i)^(?:click|tap|press)\\s+(.+?)\\s+button$"),
            Regex("(?i)^(.+?)\\s+button\\s+(?:click|press|dabao)(?:\\s+karo)?$"),
        )
        val label = patterns.firstNotNullOfOrNull { it.find(text.trim()) }?.groupValues?.get(1)?.trim()
        return label?.takeIf { it.isNotBlank() && it.length <= 80 }
            ?.let(AssistantAction::ClickAccessibleButton)
    }

    private fun parseSettings(folded: String): AssistantAction.OpenSettings? {
        if (containsAny(folded, "wifi", "wi-fi", "wireless settings")) return AssistantAction.OpenSettings(SettingsTarget.WIFI)
        if (containsAny(folded, "bluetooth", "blue tooth")) return AssistantAction.OpenSettings(SettingsTarget.BLUETOOTH)
        if (containsAny(folded, "display settings", "brightness settings", "screen settings")) {
            return AssistantAction.OpenSettings(SettingsTarget.DISPLAY)
        }
        if (containsAny(folded, "phone ki settings", "phone settings", "settings kholo", "settings open", "device settings")) {
            return AssistantAction.OpenSettings(SettingsTarget.GENERAL)
        }
        return null
    }

    private fun parseAppLaunch(text: String, folded: String): AssistantAction.OpenApp? {
        val hasOpenVerb = containsAny(folded, " kholo", " khol ", " open", " launch", " chalao", " start ") ||
            folded.startsWith("open ") || folded.startsWith("launch ")
        if (!hasOpenVerb) return null
        val apps = listOf("WhatsApp", "YouTube", "Chrome", "Camera", "Gallery", "Photos", "Calculator", "Phone", "Settings")
        return apps.firstOrNull { folded.contains(it.lowercase(Locale.ROOT)) }
            ?.let(AssistantAction::OpenApp)
            ?: Regex("(?i)^(?:open|launch|start)\\s+(.+?)\\s*$")
                .find(text.trim())?.groupValues?.get(1)?.trim()?.takeIf(String::isNotBlank)
                ?.let(AssistantAction::OpenApp)
    }

    private fun parseSearch(text: String): AssistantAction.SearchWeb? {
        val patterns = listOf(
            Regex("(?i)^(?:google\\s+(?:par|pe)|web)\\s+(?:search|dhundo|dhundho|find)\\s*(?:karo)?\\s*(.*)$"),
            Regex("(?i)^(?:google\\s+(?:par|pe)\\s+)?search\\s+(?:for|about)\\s+(.+)$"),
        )
        val match = patterns.firstNotNullOfOrNull { it.find(text.trim()) } ?: return null
        val query = match.groupValues[1].trim().trimEnd('.', '?', '!')
        return query.takeIf(String::isNotBlank)?.let(AssistantAction::SearchWeb)
    }

    private fun containsAny(value: String, vararg terms: String): Boolean = terms.any(value::contains)
}