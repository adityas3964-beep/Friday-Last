package com.aditya.friday.data

data class FridaySettings(
    val onlineAiEnabled: Boolean = false,
    val automaticRecognition: Boolean = true,
    val provider: String = "Groq",
    val endpoint: String = "https://api.groq.com/openai/v1/chat/completions",
    val modelName: String = "",
    val preferredName: String = "",
    val assistantName: String = "FRIDAY",
    val language: String = "hi-IN",
    val voiceLocale: String = "AUTO",
    val wakeWord: String = "FRIDAY",
)

data class CommandLogEntry(
    val timestamp: Long,
    val recognized: String,
    val response: String,
    val engine: String,
    val result: String,
)

data class ConversationTurn(val role: String, val content: String)

data class WhatsAppDraft(val recipient: String, val message: String)

data class ExecutionResult(
    val response: String,
    val succeeded: Boolean,
    val resultLabel: String,
)