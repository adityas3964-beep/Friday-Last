package com.aditya.friday.ai

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Url

interface GroqApi {
    @POST
    suspend fun complete(
        @Url endpoint: String,
        @Header("Authorization") authorization: String,
        @Body request: ChatCompletionRequest,
    ): Response<ChatCompletionResponse>
}

data class ChatCompletionRequest(
    val model: String,
    val messages: List<ApiMessage>,
    val stream: Boolean = false,
    val temperature: Double = 0.4,
)

data class ApiMessage(val role: String, val content: String)

data class ChatCompletionResponse(val choices: List<Choice> = emptyList()) {
    data class Choice(val message: ApiMessage? = null)
}

sealed interface AiCallResult {
    data class Success(val text: String) : AiCallResult
    data class Failure(val message: String) : AiCallResult
}