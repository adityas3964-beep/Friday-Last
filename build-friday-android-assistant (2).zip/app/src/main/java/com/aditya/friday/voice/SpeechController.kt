package com.aditya.friday.voice

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.content.ContextCompat
import com.aditya.friday.data.FridaySettings
import java.util.Locale

class SpeechController(
    context: Context,
    private val onTranscript: (String) -> Unit,
    private val onStatus: (String) -> Unit,
    private val onSpeechComplete: () -> Unit,
) : TextToSpeech.OnInitListener {
    private val appContext = context.applicationContext
    private val mainHandler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var ttsReady = false
    private var autoRequested = false
    private var pushToTalk = false
    private var currentSettings = FridaySettings()

    init {
        textToSpeech = TextToSpeech(appContext, this)
    }

    fun available(): Boolean = SpeechRecognizer.isRecognitionAvailable(appContext)

    fun startListening(settings: FridaySettings, automatic: Boolean) {
        currentSettings = settings
        if (ContextCompat.checkSelfPermission(appContext, android.Manifest.permission.RECORD_AUDIO) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            onStatus("NEEDS MICROPHONE PERMISSION")
            return
        }
        if (!available()) {
            onStatus("NO SPEECH RECOGNITION SERVICE")
            return
        }
        autoRequested = automatic
        pushToTalk = false
        startRecognitionCycle()
    }

    fun startPushToTalk(settings: FridaySettings) {
        currentSettings = settings
        autoRequested = false
        pushToTalk = true
        if (ContextCompat.checkSelfPermission(appContext, android.Manifest.permission.RECORD_AUDIO) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            pushToTalk = false
            onStatus("NEEDS MICROPHONE PERMISSION")
            return
        }
        if (!available()) {
            pushToTalk = false
            onStatus("NO SPEECH RECOGNITION SERVICE")
            return
        }
        startRecognitionCycle()
    }

    fun releasePushToTalk() {
        if (pushToTalk) runCatching { recognizer?.stopListening() }
    }

    fun stop() {
        autoRequested = false
        pushToTalk = false
        mainHandler.removeCallbacksAndMessages(null)
        runCatching { recognizer?.cancel() }
        runCatching { textToSpeech?.stop() }
        onStatus("IDLE")
        onSpeechComplete()
    }

    fun speak(message: String, settings: FridaySettings) {
        currentSettings = settings
        if (message.isBlank()) {
            onSpeechComplete()
            return
        }
        val tts = textToSpeech
        if (!ttsReady || tts == null) {
            onStatus("VOICE OUTPUT UNAVAILABLE")
            onSpeechComplete()
            if (autoRequested) scheduleRecognitionRestart()
            return
        }
        configureVoice(tts, settings)
        val utteranceId = "friday-${System.nanoTime()}"
        onStatus("SPEAKING")
        val result = tts.speak(message, TextToSpeech.QUEUE_FLUSH, Bundle(), utteranceId)
        if (result == TextToSpeech.ERROR) {
            onStatus("VOICE OUTPUT FAILED")
            onSpeechComplete()
            if (autoRequested) scheduleRecognitionRestart()
        }
    }

    fun dispose() {
        autoRequested = false
        pushToTalk = false
        mainHandler.removeCallbacksAndMessages(null)
        runCatching { recognizer?.destroy() }
        recognizer = null
        runCatching { textToSpeech?.stop(); textToSpeech?.shutdown() }
        textToSpeech = null
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        val tts = textToSpeech
        if (ttsReady && tts != null) {
            configureVoice(tts, currentSettings)
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    mainHandler.post { onStatus("SPEAKING") }
                }

                override fun onDone(utteranceId: String?) {
                    mainHandler.post {
                        onSpeechComplete()
                        if (autoRequested) scheduleRecognitionRestart()
                    }
                }

                @Deprecated("Deprecated by the platform")
                override fun onError(utteranceId: String?) {
                    mainHandler.post {
                        onStatus("VOICE OUTPUT FAILED")
                        onSpeechComplete()
                        if (autoRequested) scheduleRecognitionRestart()
                    }
                }

                override fun onError(utteranceId: String?, errorCode: Int) {
                    onError(utteranceId)
                }
            })
        }
    }

    private fun startRecognitionCycle() {
        runCatching { recognizer?.destroy() }
        recognizer = SpeechRecognizer.createSpeechRecognizer(appContext).also {
            it.setRecognitionListener(listener)
        }
        val language = currentSettings.language.ifBlank { "hi-IN" }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, language)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, language)
            putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, appContext.packageName)
        }
        onStatus("LISTENING")
        runCatching { recognizer?.startListening(intent) }
            .onFailure {
                onStatus("RECOGNITION COULD NOT START")
                if (autoRequested) scheduleRecognitionRestart()
            }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) = onStatus("LISTENING")
        override fun onBeginningOfSpeech() = onStatus("LISTENING")
        override fun onRmsChanged(rmsdB: Float) = Unit
        override fun onBufferReceived(buffer: ByteArray?) = Unit
        override fun onEndOfSpeech() = Unit

        override fun onError(error: Int) {
            when (error) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> onStatus("NEEDS MICROPHONE PERMISSION")
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> onStatus("NO SPEECH RECOGNIZED")
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> onStatus("RECOGNIZER BUSY")
                else -> onStatus("RECOGNITION ERROR $error")
            }
            if (autoRequested) scheduleRecognitionRestart()
            else {
                pushToTalk = false
                onSpeechComplete()
            }
        }

        override fun onResults(results: Bundle?) {
            val transcript = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull { it.isNotBlank() }
            if (transcript != null) {
                onStatus("THINKING")
                onTranscript(transcript)
            } else {
                onStatus("NO SPEECH RECOGNIZED")
                if (autoRequested) scheduleRecognitionRestart()
                else onSpeechComplete()
            }
        }

        override fun onPartialResults(partialResults: Bundle?) = Unit
        override fun onEvent(eventType: Int, params: Bundle?) = Unit
    }

    private fun scheduleRecognitionRestart() {
        if (!autoRequested) return
        mainHandler.removeCallbacks(restartRecognition)
        mainHandler.postDelayed(restartRecognition, 450)
    }

    private val restartRecognition = Runnable {
        if (autoRequested && !pushToTalk) startRecognitionCycle()
    }

    private fun configureVoice(tts: TextToSpeech, settings: FridaySettings) {
        val requestedLocale = when (settings.voiceLocale) {
            "hi-IN" -> Locale.forLanguageTag("hi-IN")
            "en-IN" -> Locale.forLanguageTag("en-IN")
            else -> Locale.forLanguageTag(settings.language.ifBlank { "hi-IN" })
        }
        val result = tts.setLanguage(requestedLocale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            val fallback = tts.setLanguage(Locale.forLanguageTag("en-IN"))
            if (fallback == TextToSpeech.LANG_MISSING_DATA || fallback == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.setLanguage(Locale.getDefault())
            }
        }
        val match = tts.voices?.firstOrNull { voice ->
            voice.locale.language == requestedLocale.language &&
                (requestedLocale.country.isBlank() || voice.locale.country == requestedLocale.country)
        }
        if (match != null) runCatching { tts.voice = match }
    }
}