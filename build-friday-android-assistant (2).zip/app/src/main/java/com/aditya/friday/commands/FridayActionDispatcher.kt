package com.aditya.friday.commands

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.media.AudioManager
import android.provider.Settings
import com.aditya.friday.admin.PhoneAdminReceiver
import com.aditya.friday.automation.FridayAccessibilityService
import com.aditya.friday.data.ExecutionResult
import com.aditya.friday.data.WhatsAppDraft

class FridayActionDispatcher(private val context: Context) {
    private val appLauncher = AppLauncher(context)

    fun execute(action: AssistantAction): ExecutionResult = when (action) {
        is AssistantAction.OpenApp -> {
            val result = appLauncher.openApp(action.name)
            if (result.succeeded && action.name.equals("WhatsApp", ignoreCase = true)) {
                ExecutionResult(
                    "WhatsApp opened. I have not selected a chat or sent anything.",
                    true,
                    "APP OPENED",
                )
            } else result
        }
        is AssistantAction.OpenSettings -> appLauncher.openSettings(action.target)
        is AssistantAction.SearchWeb -> appLauncher.searchWeb(action.query)
        is AssistantAction.AdjustVolume -> adjustVolume(action.direction)
        is AssistantAction.Navigate -> navigate(action.target)
        is AssistantAction.TypeText -> typeText(action.text)
        AssistantAction.ClearText -> clearText()
        is AssistantAction.ClickAccessibleButton -> clickAccessibleButton(action.label)
        is AssistantAction.OpenWhatsAppChat -> openWhatsAppChat(action.recipient)
        is AssistantAction.LockPhone -> lockPhone()
        is AssistantAction.PrepareWhatsAppMessage -> ExecutionResult(
            "A confirmation is required before any message can be sent.",
            false,
            "NEEDS CONFIRMATION",
        )
        is AssistantAction.ConfirmWhatsAppMessage -> ExecutionResult(
            "There is no pending message to confirm.",
            false,
            "ACTION FAILED",
        )
        is AssistantAction.Clarify -> ExecutionResult(action.question, false, "NEEDS CLARIFICATION")
    }

    fun sendConfirmedWhatsAppMessage(draft: WhatsAppDraft): ExecutionResult {
        if (!appLauncher.isWhatsAppInstalled()) {
            return ExecutionResult("WhatsApp is not installed. Nothing was sent.", false, "ACTION FAILED")
        }
        val service = FridayAccessibilityService.activeService
        val scheduled = service?.requestConfirmedMessage(draft.recipient, draft.message) == true
        if (scheduled) {
            return ExecutionResult(
                "Confirmed message queued in WhatsApp. I am checking the chat and send result; delivery is not guaranteed.",
                true,
                "SEND VERIFICATION PENDING",
            )
        }
        return AppLauncher(context).shareConfirmedMessage(draft.recipient, draft.message)
    }

    fun openWhatsAppChat(recipient: String): ExecutionResult {
        val opened = appLauncher.openWhatsApp()
        if (!opened.succeeded) return opened
        val serviceEnabled = isAccessibilityEnabled()
        val automationScheduled = if (serviceEnabled) {
            FridayAccessibilityService.activeService?.requestContactSearch(recipient) == true
        } else false
        return when {
            automationScheduled -> ExecutionResult(
                "WhatsApp opened. Searching for $recipient; I will only use an exact accessible match.",
                true,
                "CHAT SEARCH RUNNING",
            )
            !serviceEnabled -> ExecutionResult(
                "WhatsApp opened. Accessibility is off, so open $recipient using WhatsApp search. No chat was selected.",
                true,
                "MANUAL CHAT SELECTION",
            )
            else -> ExecutionResult(
                "WhatsApp opened, but its accessibility service is not attached. Search for $recipient manually; the chat was not verified.",
                true,
                "CHAT NOT VERIFIED",
            )
        }
    }

    private fun navigate(target: NavigationTarget): ExecutionResult {
        val service = FridayAccessibilityService.activeService
        val ok = when (target) {
            NavigationTarget.BACK -> service?.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK) == true
            NavigationTarget.HOME -> service?.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME) == true
            NavigationTarget.SCROLL_UP -> service?.scroll(AccessibilityScroll.UP) == true
            NavigationTarget.SCROLL_DOWN -> service?.scroll(AccessibilityScroll.DOWN) == true
        }
        if (!ok) {
            return ExecutionResult(
                "Android did not perform that navigation. Enable FRIDAY Accessibility for Back, Home, and scrolling.",
                false,
                if (isAccessibilityEnabled()) "SERVICE NOT ATTACHED" else "NEEDS PERMISSION",
            )
        }
        val label = when (target) {
            NavigationTarget.BACK -> "Went back."
            NavigationTarget.HOME -> "Returned to the Home screen."
            NavigationTarget.SCROLL_UP -> "Scrolled up."
            NavigationTarget.SCROLL_DOWN -> "Scrolled down."
        }
        return ExecutionResult(label, true, "ACTION SUCCESS")
    }

    private fun typeText(value: String): ExecutionResult {
        val service = FridayAccessibilityService.activeService
        val success = service?.typeIntoFocusedField(value) == true
        return if (success) {
            ExecutionResult("Entered the text in the focused field.", true, "ACTION SUCCESS")
        } else {
            ExecutionResult(
                "I could not find an accessible focused text field. Focus a supported input and try again.",
                false,
                "ACTION FAILED",
            )
        }
    }

    private fun clearText(): ExecutionResult {
        val success = FridayAccessibilityService.activeService?.clearFocusedField() == true
        return if (success) {
            ExecutionResult("Cleared the focused accessible text field.", true, "ACTION SUCCESS")
        } else {
            ExecutionResult("I could not clear a supported focused text field.", false, "ACTION FAILED")
        }
    }

    private fun clickAccessibleButton(label: String): ExecutionResult {
        val success = FridayAccessibilityService.activeService?.clickAccessibleButton(label) == true
        return if (success) {
            ExecutionResult("Tapped the visible accessible control labelled $label.", true, "ACTION SUCCESS")
        } else {
            ExecutionResult("No unique visible accessible button labelled $label was found.", false, "ACTION FAILED")
        }
    }

    private fun adjustVolume(direction: Int): ExecutionResult {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val adjustment = if (direction < 0) AudioManager.ADJUST_LOWER else AudioManager.ADJUST_RAISE
        return runCatching {
            audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, adjustment, 0)
            ExecutionResult("Media volume adjusted.", true, "ACTION SUCCESS")
        }.getOrElse {
            ExecutionResult("Android could not change media volume.", false, "ACTION FAILED")
        }
    }

    private fun lockPhone(): ExecutionResult {
        val policy = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val receiver = ComponentName(context, PhoneAdminReceiver::class.java)
        if (!policy.isAdminActive(receiver)) {
            return ExecutionResult(
                "Phone lock is not active. Activate the optional FRIDAY screen-lock permission in Settings first.",
                false,
                "NEEDS PERMISSION",
            )
        }
        return runCatching {
            policy.lockNow()
            ExecutionResult("Screen lock requested from Android.", true, "ACTION SUCCESS")
        }.getOrElse {
            ExecutionResult("Android denied the screen-lock request.", false, "ACTION FAILED")
        }
    }

    private fun isAccessibilityEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,
        ) ?: return false
        val component = ComponentName(context, FridayAccessibilityService::class.java).flattenToString()
        return enabled.split(':').any { it.equals(component, ignoreCase = true) }
    }
}

enum class AccessibilityScroll { UP, DOWN }