package com.aditya.friday.ai

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.aditya.friday.commands.AssistantAction
import com.aditya.friday.commands.CommandParser
import com.aditya.friday.commands.ConversationContextManager
import com.aditya.friday.commands.FridayActionDispatcher
import com.aditya.friday.commands.SpeechTextNormalizer
import com.aditya.friday.data.ExecutionResult
import com.aditya.friday.data.FridaySettings
import com.aditya.friday.data.SettingsRepository
import com.aditya.friday.security.ApiKeyVault
import java.util.Locale

data class AssistantOutcome(
    val response: String,
    val engine: String,
    val resultLabel: String,
)

class AssistantEngine(
    private val context: Context,
    private val settingsRepository: SettingsRepository,
    private val keyVault: ApiKeyVault,
    private val aiClient: GroqAiClient = GroqAiClient(),
    val conversation: ConversationContextManager = ConversationContextManager(),
    private val actionValidator: ActionValidator = ActionValidator(),
) {
    private val parser = CommandParser(conversation)
    private val dispatcher = FridayActionDispatcher(context)

    suspend fun handle(text: String, settings: FridaySettings): AssistantOutcome {
        val normalized = SpeechTextNormalizer.normalize(text)
        conversation.addTurn("user", normalized)
        val action = parser.parse(normalized)
        val outcome = when (action) {
            is AssistantAction.PrepareWhatsAppMessage -> requestMessageConfirmation(action, settings)
            is AssistantAction.ConfirmWhatsAppMessage -> confirmPendingMessage(action)
            is AssistantAction.OpenWhatsAppChat -> {
                val result = dispatcher.execute(action)
                if (result.succeeded) {
                    conversation.selectRecipient(action.recipient)
                    conversation.setCurrentApp("WhatsApp")
                }
                result.asOutcome("LOCAL COMMAND")
            }
            is AssistantAction.OpenApp -> {
                val result = dispatcher.execute(action)
                if (result.succeeded) conversation.setCurrentApp(action.name)
                result.asOutcome("LOCAL COMMAND")
            }
            is AssistantAction.Clarify -> ExecutionResult(action.question, false, "NEEDS CLARIFICATION")
                .asOutcome("LOCAL COMMAND")
            null -> answerConversation(normalized, settings)
            else -> dispatcher.execute(action).asOutcome("LOCAL COMMAND")
        }
        conversation.addTurn("assistant", outcome.response)
        return outcome
    }

    suspend fun testConnection(settings: FridaySettings): AiCallResult {
        val key = runCatching { keyVault.read() }.getOrNull()
            ?: return AiCallResult.Failure("Save a valid API key before testing.")
        if (settings.modelName.isBlank()) return AiCallResult.Failure("Enter a model supported by your provider first.")
        return aiClient.testConnection(settings.endpoint, settings.modelName, key)
    }

    fun keyIsSaved(): Boolean = settingsRepository.hasApiKey()

    private fun requestMessageConfirmation(
        action: AssistantAction.PrepareWhatsAppMessage,
        settings: FridaySettings,
    ): AssistantOutcome {
        if (action.draft.recipient.isBlank() || action.draft.message.isBlank()) {
            return ExecutionResult("I need both a contact and message text before I can prepare it.", false, "NEEDS CLARIFICATION")
                .asOutcome("LOCAL COMMAND")
        }
        conversation.stageMessage(action.draft)
        val name = settings.preferredName.ifBlank { "Boss" }
        return AssistantOutcome(
            response = "$name, ${action.draft.recipient} ko ‘${action.draft.message}’ message bhejna hai. Confirm karun? Reply Haan or Nahi.",
            engine = "LOCAL COMMAND",
            resultLabel = "NEEDS CONFIRMATION",
        )
    }

    private fun confirmPendingMessage(action: AssistantAction.ConfirmWhatsAppMessage): AssistantOutcome {
        val draft = conversation.takePendingMessage()
            ?: return ExecutionResult("There is no message waiting for confirmation.", false, "ACTION FAILED")
                .asOutcome("LOCAL COMMAND")
        if (!action.approved) {
            return ExecutionResult("Cancelled. No WhatsApp message was sent.", true, "CANCELLED")
                .asOutcome("LOCAL COMMAND")
        }
        return dispatcher.sendConfirmedWhatsAppMessage(draft).asOutcome("LOCAL COMMAND")
    }

    private suspend fun answerConversation(text: String, settings: FridaySettings): AssistantOutcome {
        val local = localAnswer(text, settings)
        if (local != null && !settings.onlineAiEnabled) {
            return AssistantOutcome(local, "OFFLINE MODE", "LOCAL ANSWER")
        }
        if (!settings.onlineAiEnabled) {
            return AssistantOutcome(
                "Online AI is off. Local app, settings, volume, and navigation commands still work. Enable Online AI and configure a model/key for general questions.",
                "OFFLINE MODE",
                "LOCAL COMMANDS READY",
            )
        }
        if (!hasValidatedInternet()) {
            return AssistantOutcome(
                local ?: "Internet is unavailable. I can still open apps, adjust media volume, navigate, and answer a few built-in questions.",
                "OFFLINE MODE",
                "LOCAL FALLBACK",
            )
        }
        val key = runCatching { keyVault.read() }.getOrNull()
        if (key.isNullOrBlank() || settings.modelName.isBlank()) {
            return AssistantOutcome(
                local ?: "Online AI is enabled, but its API key or model is missing. Local commands are ready.",
                "OFFLINE MODE",
                "AI NOT CONFIGURED",
            )
        }

        val result = aiClient.chat(
            endpoint = settings.endpoint,
            model = settings.modelName,
            apiKey = key,
            turns = conversation.recentTurns(),
            assistantName = settings.assistantName,
            preferredName = settings.preferredName,
        )
        return when (result) {
            is AiCallResult.Success -> {
                val validated = actionValidator.validate(result.text)
                if (validated.action == null) {
                    AssistantOutcome(validated.response, "ONLINE AI", "AI RESPONSE")
                } else {
                    val action = validated.action
                    when (action) {
                        is AssistantAction.PrepareWhatsAppMessage -> requestMessageConfirmation(action, settings)
                        is AssistantAction.OpenWhatsAppChat -> {
                            val outcome = dispatcher.execute(action)
                            if (outcome.succeeded) {
                                conversation.selectRecipient(action.recipient)
                                conversation.setCurrentApp("WhatsApp")
                            }
                            outcome.asOutcome("ONLINE AI ACTION")
                        }
                        is AssistantAction.OpenApp -> {
                            val outcome = dispatcher.execute(action)
                            if (outcome.succeeded) conversation.setCurrentApp(action.name)
                            outcome.asOutcome("ONLINE AI ACTION")
                        }
                        else -> dispatcher.execute(action).asOutcome("ONLINE AI ACTION")
                    }
                }
            }
            is AiCallResult.Failure -> AssistantOutcome(
                local ?: "${result.message} Local app and navigation commands remain available.",
                "OFFLINE MODE",
                "AI REQUEST FAILED",
            )
        }
    }

    private fun localAnswer(text: String, settings: FridaySettings): String? {
        val query = text.lowercase(Locale.ROOT)
        val salutation = settings.preferredName.takeIf(String::isNotBlank)?.let { "$it, " }.orEmpty()
        if (query.contains("india ka capital") || query.contains("india ki capital") ||
            query.contains("capital of india") || query.contains("bharat ki rajdhani") || query.contains("भारत की राजधानी")
        ) {
            return "${salutation}India ki rajdhani New Delhi hai."
        }
        if (query.contains("joke") || query.contains("majak") || query.contains("mazak")) {
            return "${salutation}Computer ne chai kyun nahi pi? Uske paas cookies pehle se thi."
        }
        if (query.contains("how are you") || query.contains("kaise ho")) {
            return "${salutation}Systems ready hain. Aapki madad ke liye yahin hoon."
        }
        return null
    }

    private fun hasValidatedInternet(): Boolean {
        val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = manager.activeNetwork ?: return false
        val capabilities = manager.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    private fun ExecutionResult.asOutcome(engine: String) = AssistantOutcome(response, engine, resultLabel)
}