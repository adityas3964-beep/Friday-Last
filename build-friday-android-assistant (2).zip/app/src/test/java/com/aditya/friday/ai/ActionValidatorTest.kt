package com.aditya.friday.ai

import com.aditya.friday.commands.AssistantAction
import com.aditya.friday.commands.NavigationTarget
import com.aditya.friday.data.WhatsAppDraft
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ActionValidatorTest {
    private val validator = ActionValidator()

    @Test
    fun acceptsOnlyKnownStructuredNavigationActions() {
        val reply = validator.validate("""{"type":"NAVIGATE","target":"BACK","response":"Going back"}""")
        assertEquals("Going back", reply.response)
        assertEquals(AssistantAction.Navigate(NavigationTarget.BACK), reply.action)
    }

    @Test
    fun rejectsUnknownActionTypesWithoutExecutingThem() {
        val reply = validator.validate("""{"type":"RUN_SHELL","code":"wipe","response":"No"}""")
        assertNull(reply.action)
    }

    @Test
    fun convertsModelMessageToPreparationNotSend() {
        val reply = validator.validate(
            """{"type":"WHATSAPP_PREPARE_SEND","recipient":"Kartavya","message":"Hi","response":"Confirm?"}""",
        )
        assertEquals(
            AssistantAction.PrepareWhatsAppMessage(WhatsAppDraft("Kartavya", "Hi")),
            reply.action,
        )
    }

    @Test
    fun plainTextRemainsAConversationReply() {
        val reply = validator.validate("Namaste")
        assertEquals("Namaste", reply.response)
        assertNull(reply.action)
    }
}