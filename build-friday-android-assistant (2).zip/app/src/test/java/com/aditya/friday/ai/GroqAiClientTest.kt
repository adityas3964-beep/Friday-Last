package com.aditya.friday.ai

import com.aditya.friday.data.ConversationTurn
import kotlinx.coroutines.runBlocking
import okhttp3.OkHttpClient
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GroqAiClientTest {
    @Test
    fun sendsOpenAiCompatibleRequestAndReturnsProviderResponse() = runBlocking {
        val server = MockWebServer()
        server.enqueue(
            MockResponse()
                .setResponseCode(200)
                .addHeader("Content-Type", "application/json")
                .setBody("""{"choices":[{"message":{"role":"assistant","content":"{\"type\":\"CHAT\",\"response\":\"ready\"}"}}]}"""),
        )
        server.start()
        try {
            val endpoint = server.url("/openai/v1/chat/completions").toString()
            val client = GroqAiClient(OkHttpClient())
            val result = client.chat(
                endpoint = endpoint,
                model = "test-model",
                apiKey = "local-test-secret",
                turns = listOf(ConversationTurn("user", "Hello")),
                assistantName = "FRIDAY",
                preferredName = "Aditya",
            )
            val request = server.takeRequest()
            assertTrue(result is AiCallResult.Success)
            assertEquals("Bearer local-test-secret", request.getHeader("Authorization"))
            assertTrue(request.path!!.contains("/openai/v1/chat/completions"))
            assertTrue(request.body.readUtf8().contains("\"model\":\"test-model\""))
        } finally {
            server.shutdown()
        }
    }

    @Test
    fun rejectsRemoteCleartextEndpointsBeforeSendingCredentials() = runBlocking {
        val result = GroqAiClient().testConnection(
            endpoint = "http://provider.example/v1/chat/completions",
            model = "test-model",
            apiKey = "not-sent",
        )
        assertTrue(result is AiCallResult.Failure)
        assertTrue((result as AiCallResult.Failure).message.contains("HTTPS"))
    }
}