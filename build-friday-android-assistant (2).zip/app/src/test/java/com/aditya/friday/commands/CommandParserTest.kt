package com.aditya.friday.commands

import com.aditya.friday.data.WhatsAppDraft
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CommandParserTest {
    private val context = ConversationContextManager()
    private val parser = CommandParser(context)

    @Test
    fun recognizesCommonHinglishCommands() {
        assertEquals(AssistantAction.OpenApp("WhatsApp"), parser.parse("FRIDAY, WhatsApp kholo."))
        assertEquals(AssistantAction.OpenApp("YouTube"), parser.parse("YouTube open karo"))
        assertEquals(AssistantAction.Navigate(NavigationTarget.BACK), parser.parse("Back jao"))
        assertEquals(AssistantAction.AdjustVolume(-1), parser.parse("Volume kam kar do"))
        assertEquals(AssistantAction.OpenSettings(SettingsTarget.WIFI), parser.parse("Wi-Fi settings kholo"))
    }

    @Test
    fun normalizesFrequentSpeechRecognitionErrors() {
        assertEquals(AssistantAction.OpenApp("WhatsApp"), parser.parse("watsapp kholo"))
        assertEquals(AssistantAction.OpenApp("Chrome"), parser.parse("chorme kholo"))
        assertEquals(AssistantAction.OpenApp("YouTube"), parser.parse("you tube khol do"))
    }

    @Test
    fun selectedRecipientIsUsedForPronounMessageAndStillNeedsConfirmation() {
        context.selectRecipient("Kartavya")
        val prepared = parser.parse("Usko Hi message bhejo")
        assertEquals(
            AssistantAction.PrepareWhatsAppMessage(WhatsAppDraft("Kartavya", "Hi")),
            prepared,
        )
        assertTrue(prepared is AssistantAction.PrepareWhatsAppMessage)
        assertEquals(null, context.pendingDraft)
    }

    @Test
    fun explicitRecipientAndTextArePreserved() {
        assertEquals(
            AssistantAction.PrepareWhatsAppMessage(WhatsAppDraft("Kartavya", "Hello There")),
            parser.parse("Kartavya ko Hello There message bhejo"),
        )
    }

    @Test
    fun previousMessageCanBeReusedOnlyWithExistingContext() {
        context.selectRecipient("Kartavya")
        context.stageMessage(WhatsAppDraft("Kartavya", "Hi there"))
        context.clearPendingMessage()
        assertEquals(
            AssistantAction.PrepareWhatsAppMessage(WhatsAppDraft("Kartavya", "Hi there")),
            parser.parse("Usko wahi message bhejo"),
        )
    }

    @Test
    fun sendWithoutRecipientAsksInsteadOfGuessing() {
        val result = parser.parse("Usko Hi bhejo")
        assertTrue(result is AssistantAction.Clarify)
        assertNull(context.pendingDraft)
    }

    @Test
    fun confirmationOnlyExistsWhenThereIsPendingMessage() {
        assertNull(parser.parse("Haan"))
        context.stageMessage(WhatsAppDraft("Kartavya", "Hi"))
        assertEquals(AssistantAction.ConfirmWhatsAppMessage(true), parser.parse("Haan"))
        assertEquals(AssistantAction.ConfirmWhatsAppMessage(false), parser.parse("Nahi"))
    }

    @Test
    fun textEntryKeepsTheUsersOriginalCapitalization() {
        assertEquals(AssistantAction.TypeText("Hello Friday"), parser.parse("Search box mein Hello Friday likho"))
    }
}