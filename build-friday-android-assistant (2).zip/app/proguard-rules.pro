# Keep Retrofit and Gson model fields available to reflection-based serialization.
-keepattributes Signature
-keepattributes *Annotation*
-keep class com.aditya.friday.ai.** { *; }