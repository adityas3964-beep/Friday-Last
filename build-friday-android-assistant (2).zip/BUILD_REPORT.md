# FRIDAY Build And Test Report

## Verified In This Environment

- Android project: `./gradlew clean testDebugUnitTest assembleDebug --no-daemon --max-workers=1 --console=plain` completed successfully.
- Toolchain: OpenJDK 17.0.21, Gradle 8.10.2, Android Gradle Plugin 8.8.2, Kotlin 2.0.21, Android SDK Platform 35, Build Tools 35.0.0.
- JVM tests: 14 tests passed, 0 failures, 0 errors, 0 skipped. Coverage includes Hinglish command parsing, speech text normalization, recipient/message context, confirmation behavior, structured-action validation, and mocked OpenAI-compatible HTTP requests.
- APK: `app/build/outputs/apk/debug/app-debug.apk` exists, is 17 MB, package ID `com.aditya.friday`, version `1.0.0`, min SDK 26, target SDK 35.
- APK integrity: `apksigner verify` passed using the Android debug certificate; `aapt dump badging` returned the expected Android package metadata; `unzip -t` found no archive errors.
- Manifest: microphone and internet permissions, Accessibility Service binding, and Device Admin receiver declarations are present in the generated APK.
- License asset: the full Apache License 2.0 text is packaged at `assets/LICENSE-APACHE-2.0.txt`.
- Browser companion: `npm run build` completed with Vite 7.3.2.

## Not Tested On A Device

No Android emulator or physical phone was available (`adb` and `emulator` are not installed in the build environment). Android runtime flows were therefore not exercised: microphone permission dialogs, platform speech recognition, Hindi/English TTS, background/lifecycle behavior, OEM settings intents, Device Admin activation, Accessibility gesture actions, or WhatsApp contact/message UI automation. These require setup and validation on a compatible Android device.

No provider API key was supplied. The networking request and response handling were exercised against a local MockWebServer; the real Groq Test Connection requires the user's own provider key, current model name, and internet access.

## Known Runtime Limitations

- There is no bundled or running always-on wake-word detector. FRIDAY reports `NOT RUNNING` and uses explicit Start Listening / Push To Talk controls.
- Android speech recognition, offline language data, and TTS voices depend on the device's installed speech services.
- Accessibility actions and WhatsApp automation depend on accessible UI labels/layouts. Message sends require explicit confirmation and are reported only after the visible local result can be checked; delivery receipts are not verified.
- The APK is debug-signed. A publisher release requires a separately managed production signing key.