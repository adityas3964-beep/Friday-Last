# Third-Party Notices

FRIDAY includes or uses the following open-source software. No third-party branding is presented as FRIDAY branding.

| Component | Use | License / notice |
| --- | --- | --- |
| AndroidX Activity, Core, Lifecycle, Compose UI/Foundation/Material 3 | Android UI and lifecycle | Apache License 2.0 - https://www.apache.org/licenses/LICENSE-2.0 |
| Kotlin and kotlinx.coroutines | Language runtime and asynchronous work | Apache License 2.0 - https://www.apache.org/licenses/LICENSE-2.0 |
| Retrofit and Gson converter | OpenAI-compatible HTTP API serialization | Apache License 2.0 - https://github.com/square/retrofit/blob/trunk/LICENSE.txt |
| OkHttp | HTTP transport | Apache License 2.0 - https://github.com/square/okhttp/blob/master/LICENSE.txt |
| Gson | JSON serialization | Apache License 2.0 - https://github.com/google/gson/blob/main/LICENSE |
| JUnit 4 | JVM unit tests | Eclipse Public License 1.0 - https://github.com/junit-team/junit4/blob/main/LICENSE |
| MockWebServer | HTTP client tests | Apache License 2.0 - https://github.com/square/okhttp/blob/master/LICENSE.txt |

The Apache License 2.0 text is included in the APK at `assets/LICENSE-APACHE-2.0.txt` and in the source project at `app/src/main/assets/LICENSE-APACHE-2.0.txt`. JUnit 4 is a test-only dependency and is not packaged into the APK. The Android SDK and Gradle plugins are development/build tools, not app source; their own distribution terms apply. Dependency versions are declared in `app/build.gradle.kts`. The application contains no downloaded third-party visual assets.